import { useCallback, useEffect, useState } from 'react';
import { Layout, type TabId } from '@/components/Layout';
import { ToastProvider, useToast } from '@/components/Toast';
import { AuthProvider, useAuth } from '@/lib/auth';
import { supabase, TABLES } from '@/lib/supabase';
import type { Representative, Subject, Student, Enrollment } from '@/lib/types';
import { AuthScreen } from '@/pages/AuthScreen';
import { Dashboard } from '@/pages/Dashboard';
import { Students } from '@/pages/Students';
import { Teachers } from '@/pages/Teachers';
import { Representatives } from '@/pages/Representatives';
import { Subjects } from '@/pages/Subjects';
import { Enrollments } from '@/pages/Enrollments';
import { Grades } from '@/pages/Grades';
import { Tools } from '@/pages/Tools';
import { Loader2 } from 'lucide-react';

function AppContent() {
  const { user, loading } = useAuth();
  const { showToast } = useToast();
  const [activeTab, setActiveTab] = useState<TabId>('dashboard');
  const [representatives, setRepresentatives] = useState<Representative[]>([]);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [students, setStudents] = useState<Student[]>([]);
  const [enrollments, setEnrollments] = useState<Enrollment[]>([]);

  const loadSharedData = useCallback(async () => {
    const [repRes, subjRes, stuRes, enrRes] = await Promise.all([
      supabase.from(TABLES.REPRESENTATIVES).select('*'),
      supabase.from(TABLES.SUBJECTS).select('*'),
      supabase.from(TABLES.STUDENTS).select('*'),
      supabase.from(TABLES.ENROLLMENTS).select('*'),
    ]);
    if (repRes.error || subjRes.error || stuRes.error || enrRes.error) {
      showToast('Error al cargar datos del sistema', 'error');
      return;
    }
    setRepresentatives(repRes.data as Representative[]);
    setSubjects(subjRes.data as Subject[]);
    setStudents(stuRes.data as Student[]);
    setEnrollments(enrRes.data as Enrollment[]);
  }, [showToast]);

  useEffect(() => {
    if (user) {
      loadSharedData();
    }
  }, [user, loadSharedData]);

  const handleTabChange = (tab: TabId) => {
    setActiveTab(tab);
    if (tab === 'enrollments' || tab === 'grades' || tab === 'students' || tab === 'teachers') {
      loadSharedData();
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
      </div>
    );
  }

  if (!user) {
    return <AuthScreen />;
  }

  return (
    <Layout activeTab={activeTab} onTabChange={handleTabChange}>
      {activeTab === 'dashboard' && <Dashboard />}
      {activeTab === 'subjects' && <Subjects />}
      {activeTab === 'teachers' && <Teachers subjects={subjects} />}
      {activeTab === 'representatives' && <Representatives />}
      {activeTab === 'students' && <Students representatives={representatives} subjects={subjects} />}
      {activeTab === 'grades' && <Grades students={students} subjects={subjects} enrollments={enrollments} representatives={representatives} />}
      {activeTab === 'enrollments' && <Enrollments students={students} subjects={subjects} />}
      {activeTab === 'tools' && <Tools />}
    </Layout>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <ToastProvider>
        <AppContent />
      </ToastProvider>
    </AuthProvider>
  );
}
