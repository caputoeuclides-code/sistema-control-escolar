import { useRef, useState } from 'react';
import type { Student, Subject, Grade, Representative } from '@/lib/types';
import { fullName, yearLabel } from '@/lib/utils';
import { X, Printer, Upload, School } from 'lucide-react';

interface BoletinModalProps {
  student: Student;
  subjects: Subject[];
  grades: Grade[];
  representative: Representative | null;
  onClose: () => void;
}

interface SubjectGrade {
  subject: Subject;
  l1: number | null;
  l2: number | null;
  l3: number | null;
  final: number | null;
}

export function BoletinModal({ student, subjects, grades, representative, onClose }: BoletinModalProps) {
  const [schoolName, setSchoolName] = useState('U.E. Sistema de Control Escolar');
  const [logoUrl, setLogoUrl] = useState<string | null>(null);
  const [observations, setObservations] = useState('');
  const printRef = useRef<HTMLDivElement>(null);

  const studentSubjects = subjects.filter((s) =>
    grades.some((g) => g.student_id === student.id && g.subject_id === s.id)
  );

  const subjectGrades: SubjectGrade[] = studentSubjects.map((subject) => {
    const getG = (lapso: number): number | null => {
      const g = grades.find((gr) => gr.student_id === student.id && gr.subject_id === subject.id && gr.lapso === lapso);
      return g ? Number(g.grade) : null;
    };
    const l1 = getG(1);
    const l2 = getG(2);
    const l3 = getG(3);
    const valid = [l1, l2, l3].filter((n): n is number => n !== null);
    const final = valid.length > 0 ? valid.reduce((a, b) => a + b, 0) / valid.length : null;
    return { subject, l1, l2, l3, final };
  });

  const allFinals = subjectGrades.map((sg) => sg.final).filter((f): f is number => f !== null);
  const promedio = allFinals.length > 0 ? allFinals.reduce((a, b) => a + b, 0) / allFinals.length : null;
  const estatus = promedio !== null ? (promedio >= 10 ? 'PROMOVIDO' : 'REPROBADO') : 'SIN NOTAS';

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => setLogoUrl(ev.target?.result as string);
    reader.readAsDataURL(file);
  };

  const handlePrint = () => {
    window.print();
  };

  const formatGrade = (g: number | null): string => {
    if (g === null) return '—';
    return g.toFixed(1);
  };

  return (
    <div className="fixed inset-0 z-[90] flex items-center justify-center p-2 sm:p-4 boletin-print-area">
      <div className="absolute inset-0 bg-black/50 backdrop-blur-sm boletin-overlay print:hidden" onClick={onClose} />

      <div className="relative z-10 w-full max-w-4xl max-h-[95vh] overflow-hidden rounded-2xl bg-white shadow-2xl boletin-container flex flex-col">
        {/* Header bar (hidden when printing) */}
        <div className="flex items-center justify-between border-b border-gray-100 px-6 py-4 flex-shrink-0 boletin-overlay print:hidden">
          <div>
            <h3 className="text-lg font-semibold text-gray-900">Boletín Informativo</h3>
            <p className="text-xs text-gray-500">{fullName(student.first_name, student.last_name)} · {yearLabel(student.school_year)} · Sección {student.section}</p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="flex items-center gap-2 rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700 transition-colors"
            >
              <Printer className="h-4 w-4" />
              Imprimir / PDF
            </button>
            <button onClick={onClose} className="text-gray-400 hover:text-gray-600 p-2">
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Editable header controls (hidden when printing) */}
        <div className="flex flex-wrap items-center gap-3 px-6 py-3 border-b border-gray-100 bg-gray-50 boletin-overlay print:hidden">
          <label className="text-xs font-medium text-gray-600">Nombre del colegio:</label>
          <input
            type="text"
            value={schoolName}
            onChange={(e) => setSchoolName(e.target.value)}
            className="flex-1 min-w-[200px] rounded-md border border-gray-200 px-3 py-1.5 text-sm focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
          />
          <label className="flex items-center gap-1.5 cursor-pointer rounded-md border border-gray-200 bg-white px-3 py-1.5 text-xs font-medium text-gray-600 hover:bg-gray-50 transition-colors">
            <Upload className="h-3.5 w-3.5" />
            Subir Logo
            <input type="file" accept="image/*" onChange={handleLogoUpload} className="hidden" />
          </label>
          {logoUrl && (
            <button onClick={() => setLogoUrl(null)} className="text-xs text-red-500 hover:text-red-700">
              Quitar logo
            </button>
          )}
        </div>

        {/* Printable area */}
        <div ref={printRef} className="overflow-y-auto boletin-content">
          <div className="mx-auto bg-white p-6 sm:p-10 boletin-page" style={{ maxWidth: '216mm', minHeight: '279mm' }}>
            {/* Membrete */}
            <div className="flex items-center justify-between border-b-2 border-gray-800 pb-4 mb-6">
              <div className="flex items-center gap-4">
                {logoUrl ? (
                  <img src={logoUrl} alt="Logo" className="h-16 w-16 object-contain" />
                ) : (
                  <div className="flex h-16 w-16 items-center justify-center rounded-lg bg-blue-600 text-white">
                    <School className="h-8 w-8" />
                  </div>
                )}
                <div>
                  <h1 className="text-lg font-bold text-gray-900">{schoolName}</h1>
                  <p className="text-xs text-gray-500">Educación Secundaria - Bolivariana</p>
                  <p className="text-xs text-gray-500">Año Escolar {new Date().getFullYear()}-{new Date().getFullYear() + 1}</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm font-bold text-gray-800">Boletín Informativo</p>
                <p className="text-xs text-gray-500">Periodo Escolar</p>
              </div>
            </div>

            {/* Student info */}
            <div className="grid grid-cols-2 gap-x-8 gap-y-2 mb-6 text-sm">
              <div className="flex justify-between border-b border-gray-200 pb-1">
                <span className="font-semibold text-gray-600">Alumno(a):</span>
                <span className="text-gray-900 text-right">{fullName(student.first_name, student.last_name)}</span>
              </div>
              <div className="flex justify-between border-b border-gray-200 pb-1">
                <span className="font-semibold text-gray-600">Cédula:</span>
                <span className="text-gray-900">{student.cedula}</span>
              </div>
              <div className="flex justify-between border-b border-gray-200 pb-1">
                <span className="font-semibold text-gray-600">Año:</span>
                <span className="text-gray-900">{yearLabel(student.school_year)}</span>
              </div>
              <div className="flex justify-between border-b border-gray-200 pb-1">
                <span className="font-semibold text-gray-600">Sección:</span>
                <span className="text-gray-900">{student.section}</span>
              </div>
              {representative && (
                <div className="flex justify-between border-b border-gray-200 pb-1">
                  <span className="font-semibold text-gray-600">Representante:</span>
                  <span className="text-gray-900 text-right">{fullName(representative.first_name, representative.last_name)}</span>
                </div>
              )}
              {representative?.phone && (
                <div className="flex justify-between border-b border-gray-200 pb-1">
                  <span className="font-semibold text-gray-600">Teléfono:</span>
                  <span className="text-gray-900">{representative.phone}</span>
                </div>
              )}
            </div>

            {/* Grades table */}
            <table className="w-full text-sm border-collapse mb-6">
              <thead>
                <tr className="bg-blue-700 text-white">
                  <th className="border border-blue-800 px-3 py-2 text-left font-semibold">Asignatura / Área de Formación</th>
                  <th className="border border-blue-800 px-3 py-2 text-center font-semibold w-20">Momento I</th>
                  <th className="border border-blue-800 px-3 py-2 text-center font-semibold w-20">Momento II</th>
                  <th className="border border-blue-800 px-3 py-2 text-center font-semibold w-20">Momento III</th>
                  <th className="border border-blue-800 px-3 py-2 text-center font-semibold w-24">Definitiva</th>
                </tr>
              </thead>
              <tbody>
                {subjectGrades.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="border border-gray-300 px-3 py-4 text-center text-gray-400">
                      No hay notas registradas para este estudiante.
                    </td>
                  </tr>
                ) : (
                  subjectGrades.map((sg, i) => (
                    <tr key={sg.subject.id} className={i % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                      <td className="border border-gray-300 px-3 py-2 text-gray-900">{sg.subject.name}</td>
                      <td className="border border-gray-300 px-3 py-2 text-center text-gray-700">{formatGrade(sg.l1)}</td>
                      <td className="border border-gray-300 px-3 py-2 text-center text-gray-700">{formatGrade(sg.l2)}</td>
                      <td className="border border-gray-300 px-3 py-2 text-center text-gray-700">{formatGrade(sg.l3)}</td>
                      <td className="border border-gray-300 px-3 py-2 text-center font-bold text-gray-900">{formatGrade(sg.final)}</td>
                    </tr>
                  ))
                )}
              </tbody>
              {subjectGrades.length > 0 && (
                <tfoot>
                  <tr className="bg-gray-100 font-bold">
                    <td className="border border-gray-300 px-3 py-2 text-right text-gray-700">Promedio General:</td>
                    <td colSpan={3} className="border border-gray-300"></td>
                    <td className="border border-gray-300 px-3 py-2 text-center text-lg text-blue-700">
                      {promedio !== null ? promedio.toFixed(2) : '—'}
                    </td>
                  </tr>
                  <tr className={estatus === 'PROMOVIDO' ? 'bg-green-50' : estatus === 'REPROBADO' ? 'bg-red-50' : 'bg-gray-50'}>
                    <td colSpan={4} className="border border-gray-300 px-3 py-2 text-right font-semibold text-gray-700">Estatus:</td>
                    <td className={`border border-gray-300 px-3 py-2 text-center font-bold text-sm ${
                      estatus === 'PROMOVIDO' ? 'text-green-700' : estatus === 'REPROBADO' ? 'text-red-700' : 'text-gray-500'
                    }`}>
                      {estatus}
                    </td>
                  </tr>
                </tfoot>
              )}
            </table>

            {/* Observations */}
            <div className="mb-8">
              <p className="text-sm font-semibold text-gray-700 mb-2">Observaciones:</p>
              <textarea
                value={observations}
                onChange={(e) => setObservations(e.target.value)}
                rows={3}
                placeholder="Escriba las observaciones del estudiante..."
                className="w-full rounded-md border border-gray-300 px-3 py-2 text-sm resize-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 boletin-observations"
                style={{ printColorAdjust: 'exact', WebkitPrintColorAdjust: 'exact' } as React.CSSProperties}
              />
            </div>

            {/* Signatures */}
            <div className="grid grid-cols-3 gap-6 mt-12 pt-4">
              <div className="text-center">
                <div className="border-t border-gray-400 pt-2">
                  <p className="text-xs text-gray-600">Firma del Docente</p>
                </div>
              </div>
              <div className="text-center">
                <div className="border-t border-gray-400 pt-2">
                  <p className="text-xs text-gray-600">Firma del Representante</p>
                </div>
              </div>
              <div className="text-center">
                <div className="border-t border-gray-400 pt-2">
                  <p className="text-xs text-gray-600">Firma de la Dirección</p>
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="mt-8 text-center text-xs text-gray-400">
              <p>Documento generado el {new Date().toLocaleDateString('es-VE', { year: 'numeric', month: 'long', day: 'numeric' })}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
