import { useState, type ReactNode } from 'react';
import {
  LayoutDashboard,
  BookOpen,
  UserCog,
  UserCheck,
  Users,
  FileText,
  ClipboardList,
  Wrench,
  Menu,
  X,
  School,
  GraduationCap,
  LogOut,
  Mail,
} from 'lucide-react';
import { useAuth } from '@/lib/auth';

export type TabId =
  | 'dashboard'
  | 'subjects'
  | 'teachers'
  | 'representatives'
  | 'students'
  | 'grades'
  | 'enrollments'
  | 'tools'

interface Tab {
  id: TabId;
  label: string;
  icon: typeof Users;
}

const TABS: Tab[] = [
  { id: 'dashboard', label: 'Inicio', icon: LayoutDashboard },
  { id: 'subjects', label: 'Materias', icon: BookOpen },
  { id: 'teachers', label: 'Profesores', icon: UserCog },
  { id: 'representatives', label: 'Representantes', icon: UserCheck },
  { id: 'students', label: 'Estudiantes', icon: Users },
  { id: 'grades', label: 'Calificaciones', icon: FileText },
  { id: 'enrollments', label: 'Asignaciones', icon: ClipboardList },
  { id: 'tools', label: 'Herramientas', icon: Wrench },
];

interface LayoutProps {
  activeTab: TabId;
  onTabChange: (tab: TabId) => void;
  children: ReactNode;
}

function SidebarFooter() {
  const { user, signOut } = useAuth();

  return (
    <div className="p-3 border-t border-gray-200">
      <div className="flex items-center gap-2 rounded-lg bg-gray-50 px-3 py-2.5 mb-2">
        <div className="flex h-8 w-8 items-center justify-center rounded-full bg-blue-100 text-blue-700 flex-shrink-0">
          <Mail className="h-4 w-4" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-xs font-medium text-gray-700 truncate" title={user?.email || ''}>
            {user?.email || 'usuario@escuela.edu.ve'}
          </p>
          <p className="text-xs text-gray-400">Sesión activa</p>
        </div>
      </div>
      <button
        onClick={() => signOut()}
        className="w-full flex items-center justify-center gap-2 rounded-lg border border-gray-200 px-3 py-2 text-sm font-medium text-gray-600 hover:bg-red-50 hover:text-red-600 hover:border-red-200 transition-colors"
      >
        <LogOut className="h-4 w-4" />
        Cerrar Sesión
      </button>
    </div>
  );
}

function NavItems({ activeTab, onTabChange }: { activeTab: TabId; onTabChange: (tab: TabId) => void }) {
  return (
    <>
      {TABS.map((tab) => {
        const Icon = tab.icon;
        const isActive = activeTab === tab.id;
        return (
          <button
            key={tab.id}
            onClick={() => onTabChange(tab.id)}
            className={`w-full flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-all ${
              isActive
                ? 'bg-blue-50 text-blue-700 border-l-4 border-blue-600'
                : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900 border-l-4 border-transparent'
            }`}
          >
            <Icon className={`h-5 w-5 flex-shrink-0 ${isActive ? 'text-blue-600' : 'text-gray-400'}`} />
            {tab.label}
          </button>
        );
      })}
    </>
  );
}

export function Layout({ activeTab, onTabChange, children }: LayoutProps) {
  const [drawerOpen, setDrawerOpen] = useState(false);

  const handleTabChange = (tab: TabId) => {
    onTabChange(tab);
    setDrawerOpen(false);
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white border-b border-gray-200 shadow-sm">
        <div className="flex items-center justify-between px-4 lg:px-6 h-16">
          <div className="flex items-center gap-3">
            <button
              className="lg:hidden text-gray-600 hover:text-gray-900"
              onClick={() => setDrawerOpen(true)}
            >
              <Menu className="h-6 w-6" />
            </button>
            <div className="flex items-center gap-2.5">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-blue-600 to-blue-800 text-white shadow-md">
                <School className="h-6 w-6" />
              </div>
              <div className="hidden sm:block">
                <h1 className="text-base font-bold text-gray-900 leading-tight">Sistema de Control Escolar</h1>
                <p className="text-xs text-gray-500 leading-tight">Educación Secundaria - Venezuela</p>
              </div>
              <h1 className="sm:hidden text-base font-bold text-gray-900">Control Escolar</h1>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span className="hidden md:flex items-center gap-1.5 text-xs font-medium text-gray-500">
              <GraduationCap className="h-4 w-4" />
              1ro a 5to Año
            </span>
          </div>
        </div>
      </header>

      {/* Desktop sidebar nav */}
      <div className="flex flex-1">
        <aside className="hidden lg:flex flex-col w-60 border-r border-gray-200 bg-white flex-shrink-0">
          <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
            <NavItems activeTab={activeTab} onTabChange={handleTabChange} />
          </nav>
          <SidebarFooter />
        </aside>

        {/* Mobile drawer */}
        {drawerOpen && (
          <div className="lg:hidden fixed inset-0 z-50">
            <div
              className="absolute inset-0 bg-black/50 backdrop-blur-sm"
              onClick={() => setDrawerOpen(false)}
            />
            <div className="absolute left-0 top-0 bottom-0 w-72 bg-white shadow-xl animate-slide-in-left flex flex-col">
              <div className="flex items-center justify-between p-4 border-b border-gray-200">
                <div className="flex items-center gap-2">
                  <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-blue-600 text-white">
                    <School className="h-5 w-5" />
                  </div>
                  <span className="font-semibold text-gray-900">Control Escolar</span>
                </div>
                <button onClick={() => setDrawerOpen(false)} className="text-gray-400 hover:text-gray-600">
                  <X className="h-5 w-5" />
                </button>
              </div>
              <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
                <NavItems activeTab={activeTab} onTabChange={handleTabChange} />
              </nav>
              <SidebarFooter />
            </div>
          </div>
        )}

        {/* Main content */}
        <main className="flex-1 overflow-x-hidden">
          <div className="p-4 lg:p-6 max-w-7xl mx-auto">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}
