import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import * as XLSX from 'xlsx';
import type { Student, Representative, Subject, Enrollment, Grade, Teacher } from '@/lib/types';
import { fullName, yearLabel } from '@/lib/utils';

interface ReportData {
  students: Student[];
  representatives: Representative[];
  yearFilter: number | 'all';
  sectionFilter: string | 'all';
}

const INSTITUTION_NAME = 'U.E. Sistema de Control Escolar';

const getReportRows = (students: Student[], representatives: Representative[]) => {
  const sorted = [...students].sort((a, b) => {
    const cmp = a.last_name.localeCompare(b.last_name, 'es');
    if (cmp !== 0) return cmp;
    return a.first_name.localeCompare(b.first_name, 'es');
  });

  return sorted.map((s, i) => {
    const rep = representatives.find((r) => r.id === s.representative_id);
    return {
      num: i + 1,
      cedula: s.cedula,
      apellidos: s.last_name,
      nombres: s.first_name,
      telefono: s.phone || '—',
      representante: rep ? fullName(rep.first_name, rep.last_name) : '—',
    };
  });
};

const getReportSubtitle = (yearFilter: number | 'all', sectionFilter: string | 'all'): string => {
  const parts: string[] = [];
  if (yearFilter !== 'all') parts.push(yearLabel(yearFilter));
  if (sectionFilter !== 'all') parts.push(`Sección ${sectionFilter}`);
  const filterText = parts.length > 0 ? parts.join(' - ') : 'Todos los años y secciones';
  return `Listado Oficial de Estudiantes — ${filterText}`;
};

export function exportStudentsPDF({ students, representatives, yearFilter, sectionFilter }: ReportData) {
  const rows = getReportRows(students, representatives);
  const subtitle = getReportSubtitle(yearFilter, sectionFilter);

  const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'letter' });
  const pageWidth = doc.internal.pageSize.getWidth();
  const margin = 15;

  // Header
  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.text(INSTITUTION_NAME, pageWidth / 2, 18, { align: 'center' });

  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.text('Listado Oficial de Estudiantes', pageWidth / 2, 26, { align: 'center' });

  // Filter info
  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  const filterParts: string[] = [];
  if (yearFilter !== 'all') filterParts.push(yearLabel(yearFilter));
  if (sectionFilter !== 'all') filterParts.push(`Sección ${sectionFilter}`);
  const filterText = filterParts.length > 0 ? filterParts.join(' - ') : 'Todos los años y secciones';
  doc.text(filterText, pageWidth / 2, 32, { align: 'center' });

  // Date
  const today = new Date().toLocaleDateString('es-VE', { year: 'numeric', month: 'long', day: 'numeric' });
  doc.setFontSize(8);
  doc.setTextColor(120);
  doc.text(`Generado el: ${today}`, pageWidth / 2, 37, { align: 'center' });
  doc.setTextColor(0);

  // Table
  autoTable(doc, {
    startY: 42,
    head: [['N°', 'Cédula', 'Apellidos', 'Nombres', 'Teléfono', 'Representante']],
    body: rows.map((r) => [r.num, r.cedula, r.apellidos, r.nombres, r.telefono, r.representante]),
    margin: { left: margin, right: margin },
    styles: {
      fontSize: 8.5,
      cellPadding: 2.5,
      lineColor: [200, 200, 200],
      lineWidth: 0.1,
      textColor: [40, 40, 40],
    },
    headStyles: {
      fillColor: [30, 64, 175],
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      fontSize: 9,
      halign: 'center',
    },
    columnStyles: {
      0: { halign: 'center', cellWidth: 12 },
      1: { halign: 'center', cellWidth: 25 },
      2: { cellWidth: 40 },
      3: { cellWidth: 40 },
      4: { halign: 'center', cellWidth: 30 },
      5: { cellWidth: 'auto' },
    },
    alternateRowStyles: { fillColor: [245, 247, 250] },
    didDrawPage: (data) => {
      // Footer
      const pageHeight = doc.internal.pageSize.getHeight();
      doc.setFontSize(7);
      doc.setTextColor(140);
      const pageCount = doc.getNumberOfPages();
      const currentPage = data.pageNumber;
      doc.text(
        `${INSTITUTION_NAME} - Página ${currentPage} de ${pageCount}`,
        pageWidth / 2,
        pageHeight - 10,
        { align: 'center' }
      );
      doc.setTextColor(0);
    },
  });

  // Total count
  const finalY = (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY;
  doc.setFontSize(9);
  doc.setFont('helvetica', 'bold');
  doc.text(`Total de estudiantes: ${rows.length}`, margin, finalY + 10);

  const fileName = `listado-estudiantes-${new Date().toISOString().slice(0, 10)}.pdf`;
  doc.save(fileName);
}

export function exportStudentsExcel({ students, representatives, yearFilter, sectionFilter }: ReportData) {
  const rows = getReportRows(students, representatives);
  const subtitle = getReportSubtitle(yearFilter, sectionFilter);

  // Build worksheet data with header rows
  const headerRows: (string | number)[][] = [
    [INSTITUTION_NAME],
    ['Listado Oficial de Estudiantes'],
    [subtitle],
    [`Generado el: ${new Date().toLocaleDateString('es-VE', { year: 'numeric', month: 'long', day: 'numeric' })}`],
    [],
    ['N°', 'Cédula', 'Apellidos', 'Nombres', 'Teléfono', 'Representante'],
  ];

  const dataRows = rows.map((r) => [r.num, r.cedula, r.apellidos, r.nombres, r.telefono, r.representante]);
  const allRows = [...headerRows, ...dataRows, [], [`Total de estudiantes: ${rows.length}`]];

  const ws = XLSX.utils.aoa_to_sheet(allRows);

  // Column widths
  ws['!cols'] = [
    { wch: 5 },
    { wch: 15 },
    { wch: 25 },
    { wch: 25 },
    { wch: 15 },
    { wch: 30 },
  ];

  // Merge title cells
  ws['!merges'] = [
    { s: { r: 0, c: 0 }, e: { r: 0, c: 5 } },
    { s: { r: 1, c: 0 }, e: { r: 1, c: 5 } },
    { s: { r: 2, c: 0 }, e: { r: 2, c: 5 } },
    { s: { r: 3, c: 0 }, e: { r: 3, c: 5 } },
  ];

  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Estudiantes');

  const fileName = `listado-estudiantes-${new Date().toISOString().slice(0, 10)}.xlsx`;
  XLSX.writeFile(wb, fileName);
}

// ===== Grades Report (Sábana de Notas) =====

interface GradesReportData {
  students: Student[];
  subjects: Subject[];
  enrollments: Enrollment[];
  grades: Grade[];
  yearFilter: number | 'all';
  sectionFilter: string | 'all';
}

interface SabanaRow {
  cedula: string;
  apellidos: string;
  nombres: string;
  subjectGrades: { subject: Subject; l1: number | null; l2: number | null; l3: number | null; final: number | null }[];
  promedio: number | null;
  estatus: string;
}

const buildSabanaRows = (
  students: Student[],
  subjects: Subject[],
  enrollments: Enrollment[],
  grades: Grade[],
): SabanaRow[] => {
  const sorted = [...students].sort((a, b) => {
    const cmp = a.last_name.localeCompare(b.last_name, 'es');
    if (cmp !== 0) return cmp;
    return a.first_name.localeCompare(b.first_name, 'es');
  });

  return sorted.map((student) => {
    const studentEnrollments = enrollments.filter((e) => e.student_id === student.id);
    const studentSubjects = studentEnrollments
      .map((e) => subjects.find((s) => s.id === e.subject_id))
      .filter(Boolean) as Subject[];

    const subjectGrades = studentSubjects.map((subject) => {
      const getG = (lapso: number): number | null => {
        const g = grades.find((gr) => gr.student_id === student.id && gr.subject_id === subject.id && gr.lapso === lapso);
        return g ? Number(g.grade) : null;
      };
      const l1 = getG(1);
      const l2 = getG(2);
      const l3 = getG(3);
      const valid = [l1, l2, l3].filter((n): n is number => n !== null);
      const final = valid.length > 0 ? valid.reduce((a, b) => a + b, 0) / valid.length : null;
      return { subject, l1, l2, l3, final };
    });

    const allFinals = subjectGrades.map((sg) => sg.final).filter((f): f is number => f !== null);
    const promedio = allFinals.length > 0 ? allFinals.reduce((a, b) => a + b, 0) / allFinals.length : null;
    const estatus = promedio !== null ? (promedio >= 10 ? 'PROMOVIDO' : 'REPROBADO') : 'SIN NOTAS';

    return {
      cedula: student.cedula,
      apellidos: student.last_name,
      nombres: student.first_name,
      subjectGrades,
      promedio,
      estatus,
    };
  });
};

const getGradesFilterText = (yearFilter: number | 'all', sectionFilter: string | 'all'): string => {
  const parts: string[] = [];
  if (yearFilter !== 'all') parts.push(yearLabel(yearFilter));
  if (sectionFilter !== 'all') parts.push(`Sección ${sectionFilter}`);
  return parts.length > 0 ? parts.join(' - ') : 'Todos los años y secciones';
};

export function exportGradesPDF({ students, subjects, enrollments, grades, yearFilter, sectionFilter }: GradesReportData) {
  const rows = buildSabanaRows(students, subjects, enrollments, grades);
  const filterText = getGradesFilterText(yearFilter, sectionFilter);

  // Collect all unique subjects across students for column headers
  const allSubjects = subjects.filter((s) =>
    rows.some((r) => r.subjectGrades.some((sg) => sg.subject.id === s.id))
  );

  const doc = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'letter' });
  const pageWidth = doc.internal.pageSize.getWidth();
  const margin = 12;

  // Header
  doc.setFontSize(14);
  doc.setFont('helvetica', 'bold');
  doc.text(INSTITUTION_NAME, pageWidth / 2, 15, { align: 'center' });

  doc.setFontSize(11);
  doc.text('Sábana de Notas Oficial', pageWidth / 2, 22, { align: 'center' });

  doc.setFontSize(8);
  doc.setFont('helvetica', 'normal');
  doc.text(filterText, pageWidth / 2, 27, { align: 'center' });

  const today = new Date().toLocaleDateString('es-VE', { year: 'numeric', month: 'long', day: 'numeric' });
  doc.setFontSize(7);
  doc.setTextColor(120);
  doc.text(`Generado el: ${today}`, pageWidth / 2, 31, { align: 'center' });
  doc.setTextColor(0);

  // Build table head: Cédula | Apellidos y Nombres | [Materia I] [Materia II] ... | Promedio | Estatus
  // Each subject gets 3 sub-columns (I, II, III)
  const head: string[][] = [[
    'Cédula',
    'Apellidos y Nombres',
    ...allSubjects.flatMap((s) => [`${s.name}\nI`, 'II', 'III']),
    'Promedio\nDef.',
    'Estatus',
  ]];

  const body = rows.map((r) => {
    const row: (string | number)[] = [
      r.cedula,
      `${r.apellidos}, ${r.nombres}`,
    ];
    allSubjects.forEach((subject) => {
      const sg = r.subjectGrades.find((x) => x.subject.id === subject.id);
      row.push(sg ? (sg.l1 !== null ? sg.l1 : '—') : '—');
      row.push(sg ? (sg.l2 !== null ? sg.l2 : '—') : '—');
      row.push(sg ? (sg.l3 !== null ? sg.l3 : '—') : '—');
    });
    row.push(r.promedio !== null ? r.promedio.toFixed(2) : '—');
    row.push(r.estatus);
    return row;
  });

  // Column styles
  const colStyles: Record<number, { halign?: 'center'; cellWidth?: number | 'auto'; fontStyle?: 'bold' }> = {};
  colStyles[0] = { halign: 'center', cellWidth: 18 };
  colStyles[1] = { cellWidth: 45 };
  allSubjects.forEach((_, i) => {
    const base = 2 + i * 3;
    colStyles[base] = { halign: 'center', cellWidth: 12 };
    colStyles[base + 1] = { halign: 'center', cellWidth: 12 };
    colStyles[base + 2] = { halign: 'center', cellWidth: 12 };
  });
  const promedioCol = 2 + allSubjects.length * 3;
  colStyles[promedioCol] = { halign: 'center', cellWidth: 16, fontStyle: 'bold' };
  colStyles[promedioCol + 1] = { halign: 'center', cellWidth: 22, fontStyle: 'bold' };

  autoTable(doc, {
    startY: 35,
    head,
    body,
    margin: { left: margin, right: margin },
    styles: {
      fontSize: 6,
      cellPadding: 1.5,
      lineColor: [200, 200, 200],
      lineWidth: 0.1,
      textColor: [40, 40, 40],
      overflow: 'linebreak',
    },
    headStyles: {
      fillColor: [30, 64, 175],
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      fontSize: 6,
      halign: 'center',
      valign: 'middle',
    },
    columnStyles: colStyles,
    alternateRowStyles: { fillColor: [245, 247, 250] },
    didParseCell: (data) => {
      // Color estatus cells
      if (data.section === 'body' && data.column.index === promedioCol + 1) {
        const val = String(data.cell.raw);
        if (val === 'PROMOVIDO') {
          data.cell.styles.textColor = [22, 101, 52];
          data.cell.styles.fillColor = [220, 252, 231];
        } else if (val === 'REPROBADO') {
          data.cell.styles.textColor = [153, 27, 27];
          data.cell.styles.fillColor = [254, 226, 226];
        }
      }
    },
    didDrawPage: (data) => {
      const pageHeight = doc.internal.pageSize.getHeight();
      doc.setFontSize(6);
      doc.setTextColor(140);
      const pageCount = doc.getNumberOfPages();
      doc.text(
        `${INSTITUTION_NAME} - Página ${data.pageNumber} de ${pageCount}`,
        pageWidth / 2,
        pageHeight - 7,
        { align: 'center' }
      );
      doc.setTextColor(0);
    },
  });

  const fileName = `sabana-notas-${new Date().toISOString().slice(0, 10)}.pdf`;
  doc.save(fileName);
}

export function exportGradesExcel({ students, subjects, enrollments, grades, yearFilter, sectionFilter }: GradesReportData) {
  const rows = buildSabanaRows(students, subjects, enrollments, grades);
  const filterText = getGradesFilterText(yearFilter, sectionFilter);

  const allSubjects = subjects.filter((s) =>
    rows.some((r) => r.subjectGrades.some((sg) => sg.subject.id === s.id))
  );

  // Header rows
  const headerRows: (string | number)[][] = [
    [INSTITUTION_NAME],
    ['Sábana de Notas Oficial'],
    [filterText],
    [`Generado el: ${new Date().toLocaleDateString('es-VE', { year: 'numeric', month: 'long', day: 'numeric' })}`],
    [],
  ];

  // Two-row header: subject name spanning 3 columns
  const headerRow1: (string)[] = ['Cédula', 'Apellidos', 'Nombres'];
  const headerRow2: (string)[] = ['', '', ''];
  allSubjects.forEach((s) => {
    headerRow1.push(s.name, '', '');
    headerRow2.push('Momento I', 'Momento II', 'Momento III');
  });
  headerRow1.push('Promedio Definitivo', 'Estatus');
  headerRow2.push('', '');

  headerRows.push(headerRow1, headerRow2);

  // Data rows — use Excel formulas for promedio
  const dataStartRow = headerRows.length + 1; // 1-indexed in Excel
  const dataRows = rows.map((r, rowIdx) => {
    const row: (string | number)[] = [r.cedula, r.apellidos, r.nombres];
    const allGradeCells: string[] = [];
    allSubjects.forEach((_, subjIdx) => {
      const sg = r.subjectGrades.find((x) => x.subject.id === allSubjects[subjIdx].id);
      const l1 = sg && sg.l1 !== null ? sg.l1 : '';
      const l2 = sg && sg.l2 !== null ? sg.l2 : '';
      const l3 = sg && sg.l3 !== null ? sg.l3 : '';
      row.push(l1, l2, l3);
      const colStart = 4 + subjIdx * 3; // 1-indexed col (D=4)
      const excelRow = dataStartRow + rowIdx;
      for (let k = 0; k < 3; k++) {
        allGradeCells.push(XLSX.utils.encode_cell({ r: excelRow - 1, c: colStart - 1 + k }));
      }
    });
    // Promedio formula: AVERAGE of all grade cells (l1, l2, l3 across subjects)
    const promedioColIdx = 3 + allSubjects.length * 3; // 0-indexed
    const promedioFormula = `IFERROR(AVERAGE(${allGradeCells.join(',')}),"")`;
    row.push(promedioFormula as unknown as string);

    // Estatus: IF(promedio>=10,"PROMOVIDO","REPROBADO")
    const promedioCellRef = XLSX.utils.encode_cell({ r: dataStartRow + rowIdx - 1, c: promedioColIdx });
    const estatusFormula = `IF(${promedioCellRef}="","SIN NOTAS",IF(${promedioCellRef}>=10,"PROMOVIDO","REPROBADO"))`;
    row.push(estatusFormula as unknown as string);

    return row;
  });

  const allRows = [...headerRows, ...dataRows];
  const ws = XLSX.utils.aoa_to_sheet(allRows);

  // Column widths
  const cols: { wch: number }[] = [
    { wch: 12 }, // Cédula
    { wch: 20 }, // Apellidos
    { wch: 20 }, // Nombres
  ];
  allSubjects.forEach(() => {
    cols.push({ wch: 8 }, { wch: 8 }, { wch: 8 });
  });
  cols.push({ wch: 14 }, { wch: 14 });
  ws['!cols'] = cols;

  // Merge subject name across 3 columns in header row 1
  const merges: XLSX.Range[] = [
    { s: { r: 0, c: 0 }, e: { r: 0, c: 3 + allSubjects.length * 3 + 1 } },
    { s: { r: 1, c: 0 }, e: { r: 1, c: 3 + allSubjects.length * 3 + 1 } },
    { s: { r: 2, c: 0 }, e: { r: 2, c: 3 + allSubjects.length * 3 + 1 } },
    { s: { r: 3, c: 0 }, e: { r: 3, c: 3 + allSubjects.length * 3 + 1 } },
    // Merge "Cédula", "Apellidos", "Nombres" across the two header rows
    { s: { r: 5, c: 0 }, e: { r: 6, c: 0 } },
    { s: { r: 5, c: 1 }, e: { r: 6, c: 1 } },
    { s: { r: 5, c: 2 }, e: { r: 6, c: 2 } },
  ];
  allSubjects.forEach((_, i) => {
    merges.push({
      s: { r: 5, c: 3 + i * 3 },
      e: { r: 5, c: 3 + i * 3 + 2 },
    });
  });
  // Merge promedio and estatus headers
  const promedioHeaderCol = 3 + allSubjects.length * 3;
  merges.push({ s: { r: 5, c: promedioHeaderCol }, e: { r: 6, c: promedioHeaderCol } });
  merges.push({ s: { r: 5, c: promedioHeaderCol + 1 }, e: { r: 6, c: promedioHeaderCol + 1 } });

  ws['!merges'] = merges;

  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Sábana de Notas');

  const fileName = `sabana-notas-${new Date().toISOString().slice(0, 10)}.xlsx`;
  XLSX.writeFile(wb, fileName);
}

// ===== Teachers Report (Nómina y Carga Académica) =====

interface TeachersReportData {
  teachers: Teacher[];
  subjects: Subject[];
}

interface TeacherRow {
  num: number;
  cedula: string;
  apellidos: string;
  nombres: string;
  telefono: string;
  materias: string;
  anosSecciones: string;
}

const buildTeacherRows = (teachers: Teacher[], subjects: Subject[]): TeacherRow[] => {
  const sorted = [...teachers].sort((a, b) => {
    const cmp = a.last_name.localeCompare(b.last_name, 'es');
    if (cmp !== 0) return cmp;
    return a.first_name.localeCompare(b.first_name, 'es');
  });

  return sorted.map((t, i) => {
    const teacherSubjects = subjects.filter((s) => s.teacher_id === t.id);
    const materias = teacherSubjects.length > 0 ? teacherSubjects.map((s) => s.name).join(', ') : 'Sin asignar';
    const anosSecciones = teacherSubjects.length > 0
      ? teacherSubjects.map((s) => yearLabel(s.school_year)).join(', ')
      : '—';
    return {
      num: i + 1,
      cedula: t.cedula,
      apellidos: t.last_name,
      nombres: t.first_name,
      telefono: t.phone || '—',
      materias,
      anosSecciones,
    };
  });
};

export function exportTeachersPDF({ teachers, subjects }: TeachersReportData) {
  const rows = buildTeacherRows(teachers, subjects);

  const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'letter' });
  const pageWidth = doc.internal.pageSize.getWidth();
  const margin = 15;

  // Header
  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.text(INSTITUTION_NAME, pageWidth / 2, 18, { align: 'center' });

  doc.setFontSize(12);
  doc.text('Nómina y Carga Académica del Personal Docente', pageWidth / 2, 26, { align: 'center' });

  const today = new Date().toLocaleDateString('es-VE', { year: 'numeric', month: 'long', day: 'numeric' });
  doc.setFontSize(8);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(120);
  doc.text(`Generado el: ${today}`, pageWidth / 2, 32, { align: 'center' });
  doc.setTextColor(0);

  autoTable(doc, {
    startY: 37,
    head: [['N°', 'Cédula', 'Apellidos', 'Nombres', 'Teléfono', 'Materias Asignadas', 'Años a su Cargo']],
    body: rows.map((r) => [r.num, r.cedula, r.apellidos, r.nombres, r.telefono, r.materias, r.anosSecciones]),
    margin: { left: margin, right: margin },
    styles: {
      fontSize: 8,
      cellPadding: 2.5,
      lineColor: [200, 200, 200],
      lineWidth: 0.1,
      textColor: [40, 40, 40],
      overflow: 'linebreak',
    },
    headStyles: {
      fillColor: [30, 64, 175],
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      fontSize: 8.5,
      halign: 'center',
      valign: 'middle',
    },
    columnStyles: {
      0: { halign: 'center', cellWidth: 10 },
      1: { halign: 'center', cellWidth: 22 },
      2: { cellWidth: 35 },
      3: { cellWidth: 35 },
      4: { halign: 'center', cellWidth: 25 },
      5: { cellWidth: 'auto' },
      6: { cellWidth: 35 },
    },
    alternateRowStyles: { fillColor: [245, 247, 250] },
    didDrawPage: (data) => {
      const pageHeight = doc.internal.pageSize.getHeight();
      doc.setFontSize(7);
      doc.setTextColor(140);
      const pageCount = doc.getNumberOfPages();
      doc.text(
        `${INSTITUTION_NAME} - Página ${data.pageNumber} de ${pageCount}`,
        pageWidth / 2,
        pageHeight - 10,
        { align: 'center' }
      );
      doc.setTextColor(0);
    },
  });

  const finalY = (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY;
  doc.setFontSize(9);
  doc.setFont('helvetica', 'bold');
  doc.text(`Total de docentes: ${rows.length}`, margin, finalY + 10);

  const fileName = `nomina-docentes-${new Date().toISOString().slice(0, 10)}.pdf`;
  doc.save(fileName);
}

export function exportTeachersExcel({ teachers, subjects }: TeachersReportData) {
  const rows = buildTeacherRows(teachers, subjects);

  const headerRows: (string | number)[][] = [
    [INSTITUTION_NAME],
    ['Nómina y Carga Académica del Personal Docente'],
    [`Generado el: ${new Date().toLocaleDateString('es-VE', { year: 'numeric', month: 'long', day: 'numeric' })}`],
    [],
    ['N°', 'Cédula', 'Apellidos', 'Nombres', 'Teléfono', 'Materias Asignadas', 'Años a su Cargo'],
  ];

  const dataRows = rows.map((r) => [r.num, r.cedula, r.apellidos, r.nombres, r.telefono, r.materias, r.anosSecciones]);
  const allRows = [...headerRows, ...dataRows, [], [`Total de docentes: ${rows.length}`]];

  const ws = XLSX.utils.aoa_to_sheet(allRows);

  ws['!cols'] = [
    { wch: 5 },
    { wch: 15 },
    { wch: 25 },
    { wch: 25 },
    { wch: 15 },
    { wch: 40 },
    { wch: 25 },
  ];

  ws['!merges'] = [
    { s: { r: 0, c: 0 }, e: { r: 0, c: 6 } },
    { s: { r: 1, c: 0 }, e: { r: 1, c: 6 } },
    { s: { r: 2, c: 0 }, e: { r: 2, c: 6 } },
  ];

  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Docentes');

  const fileName = `nomina-docentes-${new Date().toISOString().slice(0, 10)}.xlsx`;
  XLSX.writeFile(wb, fileName);
}
