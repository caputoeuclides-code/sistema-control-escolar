import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export const TABLES = {
  REPRESENTATIVES: 'representatives',
  TEACHERS: 'teachers',
  STUDENTS: 'students',
  SUBJECTS: 'subjects',
  ENROLLMENTS: 'enrollments',
  GRADES: 'grades',
} as const;

export const SCHOOL_YEARS = [
  { value: 1, label: '1er Año' },
  { value: 2, label: '2do Año' },
  { value: 3, label: '3er Año' },
  { value: 4, label: '4to Año' },
  { value: 5, label: '5to Año' },
] as const;



export const LAPSO_OPTIONS = [
  { value: 1, label: 'Lapso I' },
  { value: 2, label: 'Lapso II' },
  { value: 3, label: 'Lapso III' },
] as const;
