export interface Representative {
  id: string;
  cedula: string;
  first_name: string;
  last_name: string;
  phone: string;
  email: string;
  relationship: string;
  address: string;
  created_at?: string;
}

export interface Teacher {
  id: string;
  cedula: string;
  first_name: string;
  last_name: string;
  phone: string;
  email: string;
  specialty: string;
  address: string;
  created_at?: string;
}

export interface Student {
  id: string;
  cedula: string;
  first_name: string;
  last_name: string;
  birth_date: string | null;
  gender: string;
  school_year: number;
  section: string;
  representative_id: string | null;
  phone: string;
  address: string;
  is_repeating: boolean;
  pending_subjects: string[];
  status: string;
  created_at?: string;
}

export interface Subject {
  id: string;
  name: string;
  code: string;
  school_year: number;
  teacher_id: string | null;
  created_at?: string;
}

export interface Enrollment {
  id: string;
  student_id: string;
  subject_id: string;
  school_year: number;
  enrolled_date: string;
  status: string;
  created_at?: string;
}

export interface Grade {
  id: string;
  student_id: string;
  subject_id: string;
  lapso: number;
  grade: number;
  created_at?: string;
}

export type ToastType = 'success' | 'error' | 'info' | 'warning';

export interface Toast {
  id: string;
  message: string;
  type: ToastType;
}
