export const onlyDigits = (value: string): string => {
  return value.replace(/[^0-9]/g, '');
};

export const fullName = (first: string, last: string): string => {
  return `${first} ${last}`.trim();
};

export const yearLabel = (year: number): string => {
  const labels: Record<number, string> = {
    1: '1er Año',
    2: '2do Año',
    3: '3er Año',
    4: '4to Año',
    5: '5to Año',
  };
  return labels[year] || `${year}to Año`;
};

export const gradeColor = (grade: number): string => {
  if (grade >= 18) return 'text-green-600 font-semibold';
  if (grade >= 14) return 'text-blue-600 font-semibold';
  if (grade >= 10) return 'text-amber-600 font-semibold';
  return 'text-red-600 font-semibold';
};

export const gradeBg = (grade: number): string => {
  if (grade >= 18) return 'bg-green-100 text-green-700';
  if (grade >= 14) return 'bg-blue-100 text-blue-700';
  if (grade >= 10) return 'bg-amber-100 text-amber-700';
  return 'bg-red-100 text-red-700';
};

export const formatDate = (date: string | null): string => {
  if (!date) return '—';
  const d = new Date(date);
  return d.toLocaleDateString('es-VE', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  });
};

export const generateId = (): string => {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 9);
};
