import { useEffect, useState } from 'react';
import { supabase, TABLES, SCHOOL_YEARS } from '@/lib/supabase';
import { yearLabel } from '@/lib/utils';
import { Users, UserCog, UserCheck, BookOpen, ClipboardList, FileText, TrendingUp, AlertTriangle, School } from 'lucide-react';

interface DashboardStats {
  students: number;
  teachers: number;
  representatives: number;
  subjects: number;
  enrollments: number;
  grades: number;
  repeatingStudents: number;
  studentsByYear: { year: number; count: number }[];
}

export function Dashboard() {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const [stu, tch, rep, subj, enr, gr] = await Promise.all([
        supabase.from(TABLES.STUDENTS).select('*', { count: 'exact', head: true }),
        supabase.from(TABLES.TEACHERS).select('*', { count: 'exact', head: true }),
        supabase.from(TABLES.REPRESENTATIVES).select('*', { count: 'exact', head: true }),
        supabase.from(TABLES.SUBJECTS).select('*', { count: 'exact', head: true }),
        supabase.from(TABLES.ENROLLMENTS).select('*', { count: 'exact', head: true }),
        supabase.from(TABLES.GRADES).select('*', { count: 'exact', head: true }),
      ]);

      const { data: repeatingData } = await supabase
        .from(TABLES.STUDENTS)
        .select('school_year')
        .eq('is_repeating', true);

      const { data: yearData } = await supabase
        .from(TABLES.STUDENTS)
        .select('school_year');

      const byYear = SCHOOL_YEARS.map((y) => ({
        year: y.value,
        count: yearData?.filter((s) => s.school_year === y.value).length || 0,
      }));

      setStats({
        students: stu.count || 0,
        teachers: tch.count || 0,
        representatives: rep.count || 0,
        subjects: subj.count || 0,
        enrollments: enr.count || 0,
        grades: gr.count || 0,
        repeatingStudents: repeatingData?.length || 0,
        studentsByYear: byYear,
      });
      setLoading(false);
    })();
  }, []);

  if (loading || !stats) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="text-gray-400">Cargando panel...</div>
      </div>
    );
  }

  const cards = [
    { label: 'Estudiantes', value: stats.students, icon: Users, color: 'blue' },
    { label: 'Profesores', value: stats.teachers, icon: UserCog, color: 'green' },
    { label: 'Representantes', value: stats.representatives, icon: UserCheck, color: 'purple' },
    { label: 'Materias', value: stats.subjects, icon: BookOpen, color: 'amber' },
    { label: 'Asignaciones', value: stats.enrollments, icon: ClipboardList, color: 'cyan' },
    { label: 'Calificaciones', value: stats.grades, icon: FileText, color: 'rose' },
  ];

  const colorMap: Record<string, string> = {
    blue: 'bg-blue-50 text-blue-600',
    green: 'bg-green-50 text-green-600',
    purple: 'bg-purple-50 text-purple-600',
    amber: 'bg-amber-50 text-amber-600',
    cyan: 'bg-cyan-50 text-cyan-600',
    rose: 'bg-rose-50 text-rose-600',
  };

  const maxYearCount = Math.max(...stats.studentsByYear.map((y) => y.count), 1);

  return (
    <div>
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-gray-900">Inicio</h2>
        <p className="text-sm text-gray-500 mt-0.5">Resumen general del sistema escolar</p>
      </div>

      {/* Stats cards */}
      <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-3 mb-6">
        {cards.map((card) => {
          const Icon = card.icon;
          return (
            <div key={card.label} className="bg-white rounded-xl border border-gray-200 p-4 hover:shadow-md transition-shadow">
              <div className={`flex h-10 w-10 items-center justify-center rounded-lg mb-3 ${colorMap[card.color]}`}>
                <Icon className="h-5 w-5" />
              </div>
              <p className="text-2xl font-bold text-gray-900">{card.value}</p>
              <p className="text-xs text-gray-500 mt-0.5">{card.label}</p>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Students by year chart */}
        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <div className="flex items-center gap-2 mb-4">
            <School className="h-5 w-5 text-blue-600" />
            <h3 className="font-semibold text-gray-900">Estudiantes por Año</h3>
          </div>
          <div className="space-y-3">
            {stats.studentsByYear.map((item) => (
              <div key={item.year} className="flex items-center gap-3">
                <span className="text-sm font-medium text-gray-600 w-20 flex-shrink-0">{yearLabel(item.year)}</span>
                <div className="flex-1 bg-gray-100 rounded-full h-6 overflow-hidden">
                  <div
                    className="bg-gradient-to-r from-blue-500 to-blue-600 h-full rounded-full flex items-center justify-end pr-2 transition-all"
                    style={{ width: `${(item.count / maxYearCount) * 100}%`, minWidth: item.count > 0 ? '2rem' : '0' }}
                  >
                    {item.count > 0 && <span className="text-xs font-medium text-white">{item.count}</span>}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Alerts */}
        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <div className="flex items-center gap-2 mb-4">
            <TrendingUp className="h-5 w-5 text-blue-600" />
            <h3 className="font-semibold text-gray-900">Alertas y Resumen</h3>
          </div>
          <div className="mb-4 rounded-lg bg-blue-50 border border-blue-200 p-4">
            <p className="text-sm italic text-blue-800">"Instruir no es educar: educar es acostumbrar a querer la verdad"</p>
            <p className="text-xs text-blue-600 mt-1 text-right">— Simón Rodríguez</p>
          </div>
          <div className="space-y-3">
            {stats.repeatingStudents > 0 && (
              <div className="flex items-center gap-3 rounded-lg bg-amber-50 border border-amber-200 p-3">
                <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0" />
                <div>
                  <p className="text-sm font-medium text-amber-800">{stats.repeatingStudents} estudiante(s) repetidor(es)</p>
                  <p className="text-xs text-amber-600">Requieren seguimiento de asignaturas pendientes</p>
                </div>
              </div>
            )}
            <div className="flex items-center gap-3 rounded-lg bg-blue-50 border border-blue-200 p-3">
              <ClipboardList className="h-5 w-5 text-blue-600 flex-shrink-0" />
              <div>
                <p className="text-sm font-medium text-blue-800">{stats.enrollments} asignaciones registradas</p>
                <p className="text-xs text-blue-600">Materias inscritas en total</p>
              </div>
            </div>
            <div className="flex items-center gap-3 rounded-lg bg-green-50 border border-green-200 p-3">
              <FileText className="h-5 w-5 text-green-600 flex-shrink-0" />
              <div>
                <p className="text-sm font-medium text-green-800">{stats.grades} calificaciones registradas</p>
                <p className="text-xs text-green-600">Notas en los 3 lapsos</p>
              </div>
            </div>
            {stats.students === 0 && (
              <div className="flex items-center gap-3 rounded-lg bg-gray-50 border border-gray-200 p-3">
                <School className="h-5 w-5 text-gray-400 flex-shrink-0" />
                <div>
                  <p className="text-sm font-medium text-gray-700">Sin datos registrados</p>
                  <p className="text-xs text-gray-500">Comienza registrando estudiantes, materias y profesores</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
