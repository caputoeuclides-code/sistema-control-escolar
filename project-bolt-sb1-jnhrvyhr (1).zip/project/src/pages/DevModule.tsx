import { useState, useRef, useCallback } from 'react';
import { supabase, TABLES } from '@/lib/supabase';
import { Button } from '@/components/ui';
import { useToast } from '@/components/Toast';
import {
  Download, Upload, Trash2, AlertTriangle, Database, Table, RefreshCw,
  CheckCircle2, Loader2, ShieldAlert,
} from 'lucide-react';

interface TableInfo {
  name: string;
  label: string;
  count: number;
}

type ExportData = Record<string, unknown[]>;

const TABLE_LABELS: Record<string, string> = {
  representatives: 'Representantes',
  teachers: 'Profesores',
  students: 'Estudiantes',
  subjects: 'Materias',
  enrollments: 'Inscripciones',
  grades: 'Notas',
};

const TABLE_ORDER = [
  TABLES.REPRESENTATIVES,
  TABLES.TEACHERS,
  TABLES.STUDENTS,
  TABLES.SUBJECTS,
  TABLES.ENROLLMENTS,
  TABLES.GRADES,
];

export function DevModule() {
  const { showToast } = useToast();
  const [tableInfo, setTableInfo] = useState<TableInfo[]>([]);
  const [loading, setLoading] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [importing, setImporting] = useState(false);
  const [resetting, setResetting] = useState(false);
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const [resetConfirmText, setResetConfirmText] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const fetchStats = useCallback(async () => {
    setLoading(true);
    try {
      const results = await Promise.all(
        TABLE_ORDER.map(async (table) => {
          const { count, error } = await supabase
            .from(table)
            .select('*', { count: 'exact', head: true });
          return {
            name: table,
            label: TABLE_LABELS[table] || table,
            count: error ? 0 : count || 0,
          };
        })
      );
      setTableInfo(results);
    } catch {
      showToast('Error al cargar estadísticas de la base de datos', 'error');
    } finally {
      setLoading(false);
    }
  }, [showToast]);

  const handleExport = async () => {
    setExporting(true);
    try {
      const data: ExportData = {};
      for (const table of TABLE_ORDER) {
        const { data: rows, error } = await supabase.from(table).select('*');
        if (error) throw error;
        data[table] = rows || [];
      }

      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      const date = new Date().toISOString().split('T')[0];
      link.href = url;
      link.download = `respaldo-control-escolar-${date}.json`;
      link.click();
      URL.revokeObjectURL(url);
      showToast('Respaldo exportado correctamente', 'success');
    } catch {
      showToast('Error al exportar los datos', 'error');
    } finally {
      setExporting(false);
    }
  };

  const handleImportClick = () => {
    fileInputRef.current?.click();
  };

  const handleImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setImporting(true);
    try {
      const text = await file.text();
      const data = JSON.parse(text) as ExportData;

      if (!data || typeof data !== 'object') {
        showToast('Archivo inválido: formato incorrecto', 'error');
        return;
      }

      for (const table of TABLE_ORDER) {
        const rows = data[table];
        if (!rows || !Array.isArray(rows)) continue;

        await supabase.from(table).delete().neq('id', '00000000-0000-0000-0000-000000000000');

        if (rows.length > 0) {
          const { error } = await supabase.from(table).insert(rows);
          if (error) throw error;
        }
      }

      showToast('Datos importados correctamente', 'success');
      await fetchStats();
    } catch {
      showToast('Error al importar los datos. Verifica el archivo.', 'error');
    } finally {
      setImporting(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleReset = async () => {
    setResetting(true);
    try {
      for (const table of [...TABLE_ORDER].reverse()) {
        const { error } = await supabase
          .from(table)
          .delete()
          .neq('id', '00000000-0000-0000-0000-000000000000');
        if (error) throw error;
      }
      showToast('Base de datos reseteada correctamente', 'success');
      await fetchStats();
    } catch {
      showToast('Error al resetear la base de datos', 'error');
    } finally {
      setResetting(false);
      setShowResetConfirm(false);
      setResetConfirmText('');
    }
  };

  const totalRecords = tableInfo.reduce((sum, t) => sum + t.count, 0);

  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Database className="h-5 w-5 text-blue-600" />
            <h3 className="font-semibold text-gray-900">Estado de la Base de Datos</h3>
          </div>
          <Button variant="ghost" size="sm" onClick={fetchStats} disabled={loading}>
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <RefreshCw className="h-4 w-4" />}
            Actualizar
          </Button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
          {tableInfo.length === 0 && !loading ? (
            <div className="col-span-full text-center py-6">
              <Table className="h-8 w-8 text-gray-300 mx-auto mb-2" />
              <p className="text-sm text-gray-400">Haz clic en "Actualizar" para ver las estadísticas</p>
            </div>
          ) : (
            <>
              {tableInfo.map((t) => (
                <div key={t.name} className="rounded-lg border border-gray-200 p-4 bg-gray-50">
                  <div className="flex items-center gap-2 mb-1">
                    <Table className="h-4 w-4 text-gray-400" />
                    <span className="text-xs font-medium text-gray-500">{t.label}</span>
                  </div>
                  <p className="text-2xl font-bold text-gray-900">{t.count}</p>
                  <p className="text-xs text-gray-400">registros</p>
                </div>
              ))}
              <div className="rounded-lg border border-blue-200 p-4 bg-blue-50">
                <div className="flex items-center gap-2 mb-1">
                  <Database className="h-4 w-4 text-blue-500" />
                  <span className="text-xs font-medium text-blue-600">Total</span>
                </div>
                <p className="text-2xl font-bold text-blue-700">{totalRecords}</p>
                <p className="text-xs text-blue-400">registros</p>
              </div>
            </>
          )}
        </div>
      </div>

      {/* Export / Import */}
      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <h3 className="font-semibold text-gray-900 mb-1">Copia de Seguridad</h3>
        <p className="text-sm text-gray-500 mb-4">
          Exporta todos los datos del sistema en formato JSON o restaura desde un respaldo anterior.
        </p>
        <div className="flex flex-wrap gap-3">
          <Button onClick={handleExport} disabled={exporting}>
            {exporting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Download className="h-4 w-4" />}
            Exportar Respaldo
          </Button>
          <Button variant="outline" onClick={handleImportClick} disabled={importing}>
            {importing ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />}
            Importar Respaldo
          </Button>
          <input
            ref={fileInputRef}
            type="file"
            accept="application/json,.json"
            onChange={handleImport}
            className="hidden"
          />
        </div>
        <div className="mt-3 rounded-lg bg-amber-50 border border-amber-200 p-3 flex items-start gap-2">
          <AlertTriangle className="h-4 w-4 text-amber-500 flex-shrink-0 mt-0.5" />
          <p className="text-xs text-amber-700">
            La importación reemplaza todos los datos actuales. Se recomienda exportar una copia de seguridad antes de importar.
          </p>
        </div>
      </div>

      {/* Danger Zone */}
      <div className="bg-white rounded-xl border-2 border-red-200 p-6">
        <div className="flex items-center gap-2 mb-1">
          <ShieldAlert className="h-5 w-5 text-red-600" />
          <h3 className="font-semibold text-red-700">Zona de Peligro</h3>
        </div>
        <p className="text-sm text-gray-500 mb-4">
          El reseteo elimina permanentemente todos los registros del sistema. Esta acción no se puede deshacer.
        </p>

        {!showResetConfirm ? (
          <Button variant="danger" onClick={() => setShowResetConfirm(true)}>
            <Trash2 className="h-4 w-4" />
            Resetear Base de Datos
          </Button>
        ) : (
          <div className="space-y-4 rounded-lg bg-red-50 border border-red-200 p-4">
            <div className="flex items-start gap-2">
              <AlertTriangle className="h-5 w-5 text-red-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-sm font-medium text-red-800">Confirmar reseteo completo</p>
                <p className="text-xs text-red-600 mt-1">
                  Se eliminarán todos los representantes, profesores, estudiantes, materias, inscripciones y notas.
                </p>
              </div>
            </div>
            <div>
              <label className="text-sm font-medium text-red-700 mb-1.5 block">
                Escribe <span className="font-bold">ELIMINAR</span> para confirmar:
              </label>
              <input
                type="text"
                value={resetConfirmText}
                onChange={(e) => setResetConfirmText(e.target.value)}
                placeholder="ELIMINAR"
                className="w-full rounded-lg border border-red-300 px-3 py-2 text-sm text-red-700 outline-none focus:ring-2 focus:ring-red-200 uppercase"
              />
            </div>
            <div className="flex gap-3">
              <Button
                variant="danger"
                onClick={handleReset}
                disabled={resetConfirmText !== 'ELIMINAR' || resetting}
              >
                {resetting ? <Loader2 className="h-4 w-4 animate-spin" /> : <CheckCircle2 className="h-4 w-4" />}
                Confirmar Reset
              </Button>
              <Button
                variant="outline"
                onClick={() => { setShowResetConfirm(false); setResetConfirmText(''); }}
              >
                Cancelar
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
