import { useCallback, useEffect, useState } from 'react';
import { supabase, TABLES, SCHOOL_YEARS } from '@/lib/supabase';
import type { Student, Subject, Enrollment } from '@/lib/types';
import { useToast } from '@/components/Toast';
import { Modal } from '@/components/Modal';
import { Badge, Button, EmptyState, Input, Select } from '@/components/ui';
import { fullName, yearLabel } from '@/lib/utils';
import { ClipboardList, Plus, Search, AlertTriangle, CheckCircle2, BookOpen, X } from 'lucide-react';

interface EnrollmentsProps {
  students: Student[];
  subjects: Subject[];
}

interface EnrollmentWithSubject extends Enrollment {
  subject?: Subject;
}

export function Enrollments({ students, subjects }: EnrollmentsProps) {
  const { showToast } = useToast();
  const [enrollments, setEnrollments] = useState<EnrollmentWithSubject[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filterYear, setFilterYear] = useState<number | 'all'>('all');
  const [modalOpen, setModalOpen] = useState(false);
  const [selectedStudent, setSelectedStudent] = useState<string>('');
  const [selectedSubjectIds, setSelectedSubjectIds] = useState<string[]>([]);

  const load = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase.from(TABLES.ENROLLMENTS).select('*');
    if (error) { showToast('Error al cargar inscripciones', 'error'); }
    else {
      const enriched = (data as Enrollment[]).map((e) => ({
        ...e,
        subject: subjects.find((s) => s.id === e.subject_id),
      }));
      setEnrollments(enriched);
    }
    setLoading(false);
  }, [showToast, subjects]);

  useEffect(() => { load(); }, [load]);

  const enrolledSubjectIds = (studentId: string): string[] => {
    return enrollments.filter((e) => e.student_id === studentId).map((e) => e.subject_id);
  };

  const openEnrollModal = () => {
    setSelectedStudent('');
    setSelectedSubjectIds([]);
    setModalOpen(true);
  };

  const handleStudentSelect = (studentId: string) => {
    setSelectedStudent(studentId);
    // Pre-select subjects for the student's year
    const student = students.find((s) => s.id === studentId);
    if (student) {
      const yearSubjects = subjects.filter((s) => s.school_year === student.school_year);
      const alreadyEnrolled = enrolledSubjectIds(studentId);
      setSelectedSubjectIds(yearSubjects.map((s) => s.id).filter((id) => !alreadyEnrolled.includes(id)));
      // Include pending subjects
      if (student.pending_subjects && student.pending_subjects.length > 0) {
        setSelectedSubjectIds((prev) => [...new Set([...prev, ...student.pending_subjects])]);
      }
    }
  };

  const toggleSubject = (subjectId: string) => {
    setSelectedSubjectIds((prev) =>
      prev.includes(subjectId) ? prev.filter((id) => id !== subjectId) : [...prev, subjectId]
    );
  };

  const handleEnroll = async () => {
    if (!selectedStudent) { showToast('Selecciona un estudiante', 'warning'); return; }
    if (selectedSubjectIds.length === 0) { showToast('Selecciona al menos una materia', 'warning'); return; }

    const student = students.find((s) => s.id === selectedStudent);
    if (!student) return;

    const existing = enrolledSubjectIds(selectedStudent);
    const toInsert = selectedSubjectIds
      .filter((id) => !existing.includes(id))
      .map((subjectId) => {
        const subject = subjects.find((s) => s.id === subjectId);
        return {
          student_id: selectedStudent,
          subject_id: subjectId,
          school_year: subject?.school_year || student.school_year,
          status: 'activo',
        };
      });

    if (toInsert.length === 0) {
      showToast('Las materias seleccionadas ya están inscritas', 'info');
      setModalOpen(false);
      return;
    }

    const { error } = await supabase.from(TABLES.ENROLLMENTS).insert(toInsert);
    if (error) { showToast('Error al inscribir materias', 'error'); return; }
    showToast(`${toInsert.length} materia(s) inscrita(s) correctamente`, 'success');
    setModalOpen(false);
    load();
  };

  const handleUnenroll = async (enrollmentId: string) => {
    const { error } = await supabase.from(TABLES.ENROLLMENTS).delete().eq('id', enrollmentId);
    if (error) { showToast('Error al retirar materia', 'error'); return; }
    showToast('Materia retirada correctamente', 'success');
    load();
  };

  const filteredStudents = students.filter((s) => {
    const matchesSearch = fullName(s.first_name, s.last_name).toLowerCase().includes(search.toLowerCase()) || s.cedula.includes(search);
    const matchesYear = filterYear === 'all' || s.school_year === filterYear;
    return matchesSearch && matchesYear;
  });

  const studentEnrollments = (studentId: string) => enrollments.filter((e) => e.student_id === studentId);

  return (
    <div>
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-6">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Inscripciones</h2>
          <p className="text-sm text-gray-500 mt-0.5">{enrollments.length} inscripciones registradas</p>
        </div>
        <Button onClick={openEnrollModal}><Plus className="h-4 w-4" /> Nueva Inscripción</Button>
      </div>

      <div className="flex flex-col sm:flex-row gap-3 mb-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input placeholder="Buscar estudiante..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-10 w-full" />
        </div>
        <Select value={filterYear} onChange={(e) => setFilterYear(e.target.value === 'all' ? 'all' : Number(e.target.value))} className="sm:w-40">
          <option value="all">Todos los años</option>
          {SCHOOL_YEARS.map((y) => <option key={y.value} value={y.value}>{y.label}</option>)}
        </Select>
      </div>

      {loading ? (
        <div className="bg-white rounded-xl border border-gray-200 p-8 text-center text-gray-400">Cargando...</div>
      ) : filteredStudents.length === 0 ? (
        <div className="bg-white rounded-xl border border-gray-200">
          <EmptyState
            icon={<ClipboardList className="h-8 w-8" />}
            title="No hay estudiantes para mostrar"
            description="Registra estudiantes primero para poder inscribirlos en materias."
          />
        </div>
      ) : (
        <div className="space-y-3">
          {filteredStudents.map((student) => {
            const enrs = studentEnrollments(student.id);
            const hasPending = student.is_repeating || (student.pending_subjects && student.pending_subjects.length > 0);
            return (
              <div key={student.id} className="bg-white rounded-xl border border-gray-200 overflow-hidden">
                <div className="px-4 py-3 border-b border-gray-100 flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-3">
                    <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-blue-100 text-blue-700 text-xs font-bold">
                      {student.school_year}°
                    </div>
                    <div>
                      <p className="font-semibold text-gray-900 text-sm">{fullName(student.first_name, student.last_name)}</p>
                      <p className="text-xs text-gray-500">C.I: {student.cedula} · {yearLabel(student.school_year)} - Sección {student.section}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {hasPending && (
                      <Badge color="amber">
                        <AlertTriangle className="h-3 w-3 mr-1 inline" />
                        {student.is_repeating ? 'Repetidor' : ''} {student.pending_subjects?.length > 0 ? `${student.pending_subjects.length} pendiente(s)` : ''}
                      </Badge>
                    )}
                    <Badge color={enrs.length > 0 ? 'blue' : 'gray'}>{enrs.length} materia(s)</Badge>
                  </div>
                </div>
                {enrs.length > 0 ? (
                  <div className="px-4 py-3">
                    <div className="flex flex-wrap gap-2">
                      {enrs.map((e) => (
                        <div key={e.id} className="inline-flex items-center gap-2 rounded-lg bg-gray-50 border border-gray-200 px-3 py-1.5 text-sm">
                          <BookOpen className="h-3.5 w-3.5 text-gray-400" />
                          <span className="text-gray-700">{e.subject?.name || 'Materia'}</span>
                          <span className="text-xs text-gray-400">({yearLabel(e.subject?.school_year || e.school_year)})</span>
                          <button
                            onClick={() => handleUnenroll(e.id)}
                            className="text-gray-300 hover:text-red-500 transition-colors"
                          >
                            <X className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div className="px-4 py-3 text-sm text-gray-400">Sin materias inscritas</div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Enrollment Modal */}
      <Modal
        open={modalOpen}
        title="Inscripción de Materias"
        onClose={() => setModalOpen(false)}
        size="lg"
      >
        <div className="space-y-4">
          <div>
            <label className="text-sm font-medium text-gray-700 mb-1.5 block">Estudiante</label>
            <Select value={selectedStudent} onChange={(e) => handleStudentSelect(e.target.value)} className="w-full">
              <option value="">Seleccionar estudiante...</option>
              {students.map((s) => (
                <option key={s.id} value={s.id}>
                  {fullName(s.first_name, s.last_name)} - {s.cedula} ({yearLabel(s.school_year)})
                </option>
              ))}
            </Select>
          </div>

          {selectedStudent && (() => {
            const student = students.find((s) => s.id === selectedStudent);
            if (!student) return null;
            const existing = enrolledSubjectIds(selectedStudent);
            const yearSubjects = subjects.filter((s) => s.school_year === student.school_year);
            const otherYearSubjects = subjects.filter((s) => s.school_year !== student.school_year);
            const pendingIds = student.pending_subjects || [];

            return (
              <div className="space-y-4">
                {student.is_repeating && (
                  <div className="rounded-lg bg-amber-50 border border-amber-200 p-3 flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div className="text-sm">
                      <p className="font-medium text-amber-800">Estudiante Repetidor</p>
                      <p className="text-amber-700 text-xs mt-0.5">Este estudiante está repitiendo el año. Verifica las materias pendientes seleccionadas abajo.</p>
                    </div>
                  </div>
                )}

                {pendingIds.length > 0 && (
                  <div className="rounded-lg bg-red-50 border border-red-200 p-3">
                    <div className="flex items-center gap-2 mb-2">
                      <AlertTriangle className="h-4 w-4 text-red-600" />
                      <span className="text-sm font-medium text-red-800">Asignaturas Pendientes ({pendingIds.length})</span>
                    </div>
                    <p className="text-xs text-red-700 mb-2">Materias pendientes de años anteriores (pre-seleccionadas):</p>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {pendingIds.map((id) => {
                        const subject = subjects.find((s) => s.id === id);
                        if (!subject) return null;
                        return (
                          <label key={id} className="flex items-center gap-2 cursor-pointer text-sm rounded-md bg-white px-2 py-1.5 border border-red-100">
                            <input
                              type="checkbox"
                              checked={selectedSubjectIds.includes(id)}
                              onChange={() => toggleSubject(id)}
                              className="h-4 w-4 rounded border-gray-300 text-red-600 focus:ring-red-500"
                            />
                            <span className="text-gray-700">{subject.name}</span>
                            <span className="text-xs text-red-500 ml-auto">{yearLabel(subject.school_year)}</span>
                          </label>
                        );
                      })}
                    </div>
                  </div>
                )}

                <div className="rounded-lg border border-gray-200 p-4">
                  <div className="flex items-center gap-2 mb-3">
                    <BookOpen className="h-4 w-4 text-blue-600" />
                    <span className="text-sm font-medium text-gray-700">Materias de {yearLabel(student.school_year)}</span>
                  </div>
                  {yearSubjects.length === 0 ? (
                    <p className="text-sm text-gray-400">No hay materias registradas para este año.</p>
                  ) : (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {yearSubjects.map((s) => {
                        const isEnrolled = existing.includes(s.id);
                        return (
                          <label key={s.id} className={`flex items-center gap-2 cursor-pointer text-sm rounded-md px-2 py-1.5 border ${isEnrolled ? 'bg-green-50 border-green-200' : 'bg-white border-gray-200'}`}>
                            <input
                              type="checkbox"
                              checked={isEnrolled || selectedSubjectIds.includes(s.id)}
                              disabled={isEnrolled}
                              onChange={() => toggleSubject(s.id)}
                              className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                            />
                            <span className="text-gray-700">{s.name}</span>
                            {isEnrolled && <CheckCircle2 className="h-3.5 w-3.5 text-green-500 ml-auto" />}
                          </label>
                        );
                      })}
                    </div>
                  )}
                </div>

                {otherYearSubjects.length > 0 && (
                  <div className="rounded-lg border border-gray-200 p-4">
                    <div className="flex items-center gap-2 mb-3">
                      <BookOpen className="h-4 w-4 text-gray-400" />
                      <span className="text-sm font-medium text-gray-600">Materias de Otros Años</span>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-48 overflow-y-auto">
                      {otherYearSubjects.map((s) => {
                        const isEnrolled = existing.includes(s.id);
                        return (
                          <label key={s.id} className={`flex items-center gap-2 cursor-pointer text-sm rounded-md px-2 py-1.5 border ${isEnrolled ? 'bg-green-50 border-green-200' : 'bg-white border-gray-200'}`}>
                            <input
                              type="checkbox"
                              checked={isEnrolled || selectedSubjectIds.includes(s.id)}
                              disabled={isEnrolled}
                              onChange={() => toggleSubject(s.id)}
                              className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                            />
                            <span className="text-gray-700">{s.name}</span>
                            <span className="text-xs text-gray-400 ml-auto">{yearLabel(s.school_year)}</span>
                          </label>
                        );
                      })}
                    </div>
                  </div>
                )}

                <div className="rounded-lg bg-blue-50 p-3 text-sm text-blue-700">
                  <strong>{selectedSubjectIds.filter((id) => !existing.includes(id)).length}</strong> materia(s) seleccionada(s) para inscribir
                </div>
              </div>
            );
          })()}

          <div className="flex justify-end gap-3 pt-2 border-t border-gray-100">
            <Button variant="outline" onClick={() => setModalOpen(false)}>Cancelar</Button>
            <Button onClick={handleEnroll} disabled={!selectedStudent}>
              <CheckCircle2 className="h-4 w-4" />
              Confirmar Inscripción
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
