import { useCallback, useEffect, useState } from 'react';
import { supabase, TABLES, SCHOOL_YEARS, LAPSO_OPTIONS } from '@/lib/supabase';
import type { Student, Subject, Enrollment, Grade, Representative } from '@/lib/types';
import { useToast } from '@/components/Toast';
import { Badge, Button, EmptyState, Input, Select } from '@/components/ui';
import { fullName, yearLabel, gradeColor, gradeBg } from '@/lib/utils';
import { FileText, Save, Search, FileDown, FileSpreadsheet, ScrollText } from 'lucide-react';
import { exportGradesPDF, exportGradesExcel } from '@/lib/exportReports';
import { BoletinModal } from '@/components/BoletinModal';

interface GradesProps {
  students: Student[];
  subjects: Subject[];
  enrollments: Enrollment[];
  representatives: Representative[];
}

interface GradeRow {
  subject: Subject;
  grades: Record<number, number | null>;
}

export function Grades({ students, subjects, enrollments, representatives }: GradesProps) {
  const { showToast } = useToast();
  const [grades, setGrades] = useState<Grade[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filterYear, setFilterYear] = useState<number | 'all'>('all');
  const [filterSection, setFilterSection] = useState<string | 'all'>('all');
  const [selectedLapso, setSelectedLapso] = useState<number>(1);
  const [editingStudent, setEditingStudent] = useState<string>('');
  const [editValues, setEditValues] = useState<Record<string, string>>({});
  const [boletinStudent, setBoletinStudent] = useState<Student | null>(null);

  const loadGrades = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase.from(TABLES.GRADES).select('*');
    if (error) { showToast('Error al cargar notas', 'error'); }
    else { setGrades(data as Grade[]); }
    setLoading(false);
  }, [showToast]);

  useEffect(() => { loadGrades(); }, [loadGrades]);

  const getGrade = (studentId: string, subjectId: string, lapso: number): number | null => {
    const g = grades.find((gr) => gr.student_id === studentId && gr.subject_id === subjectId && gr.lapso === lapso);
    return g ? Number(g.grade) : null;
  };

  const getAverage = (studentId: string): string => {
    const studentGrades = grades.filter((g) => g.student_id === studentId);
    if (studentGrades.length === 0) return '—';
    const total = studentGrades.reduce((sum, g) => sum + Number(g.grade), 0);
    return (total / studentGrades.length).toFixed(2);
  };

  const filteredStudents = students.filter((s) => {
    const matchesSearch = fullName(s.first_name, s.last_name).toLowerCase().includes(search.toLowerCase()) || s.cedula.includes(search);
    const matchesYear = filterYear === 'all' || s.school_year === filterYear;
    const matchesSection = filterSection === 'all' || s.section === filterSection;
    return matchesSearch && matchesYear && matchesSection;
  });

  const handleExportPDF = () => {
    if (filteredStudents.length === 0) {
      showToast('No hay estudiantes para exportar con los filtros actuales', 'warning');
      return;
    }
    exportGradesPDF({
      students: filteredStudents,
      subjects,
      enrollments,
      grades,
      yearFilter: filterYear,
      sectionFilter: filterSection,
    });
    showToast('PDF de la sábana de notas descargado correctamente', 'success');
  };

  const handleExportExcel = () => {
    if (filteredStudents.length === 0) {
      showToast('No hay estudiantes para exportar con los filtros actuales', 'warning');
      return;
    }
    exportGradesExcel({
      students: filteredStudents,
      subjects,
      enrollments,
      grades,
      yearFilter: filterYear,
      sectionFilter: filterSection,
    });
    showToast('Excel de la sábana de notas descargado correctamente', 'success');
  };

  const studentEnrolledSubjects = (studentId: string): Subject[] => {
    const studentEnrollments = enrollments.filter((e) => e.student_id === studentId);
    return studentEnrollments
      .map((e) => subjects.find((s) => s.id === e.subject_id))
      .filter(Boolean) as Subject[];
  };

  const openGradeEditor = (studentId: string) => {
    setEditingStudent(studentId);
    const studentSubjects = studentEnrolledSubjects(studentId);
    const vals: Record<string, string> = {};
    studentSubjects.forEach((subj) => {
      LAPSO_OPTIONS.forEach((lapso) => {
        const g = getGrade(studentId, subj.id, lapso.value);
        vals[`${subj.id}-${lapso.value}`] = g !== null ? String(g) : '';
      });
    });
    setEditValues(vals);
  };

  const handleGradeChange = (subjectId: string, lapso: number, value: string) => {
    // Only allow digits and decimal point, max 20
    let val = value.replace(/[^0-9.]/g, '');
    if (val === '') {
      setEditValues((prev) => ({ ...prev, [`${subjectId}-${lapso}`]: '' }));
      return;
    }
    const num = parseFloat(val);
    if (isNaN(num)) return;
    if (num > 20) val = '20';
    if (num < 0) val = '0';
    setEditValues((prev) => ({ ...prev, [`${subjectId}-${lapso}`]: val }));
  };

  const handleSaveGrades = async () => {
    if (!editingStudent) return;
    const studentSubjects = studentEnrolledSubjects(editingStudent);
    let savedCount = 0;

    for (const subj of studentSubjects) {
      for (const lapso of LAPSO_OPTIONS) {
        const key = `${subj.id}-${lapso.value}`;
        const valStr = editValues[key];
        const existing = grades.find((g) => g.student_id === editingStudent && g.subject_id === subj.id && g.lapso === lapso.value);

        if (valStr === '' || valStr === undefined) {
          // If existing grade and now empty, delete it
          if (existing) {
            await supabase.from(TABLES.GRADES).delete().eq('id', existing.id);
          }
          continue;
        }

        const numVal = parseFloat(valStr);
        if (isNaN(numVal) || numVal < 0 || numVal > 20) continue;

        if (existing) {
          if (Number(existing.grade) !== numVal) {
            const { error } = await supabase.from(TABLES.GRADES).update({ grade: numVal }).eq('id', existing.id);
            if (!error) savedCount++;
          }
        } else {
          const { error } = await supabase.from(TABLES.GRADES).insert({
            student_id: editingStudent,
            subject_id: subj.id,
            lapso: lapso.value,
            grade: numVal,
          });
          if (!error) savedCount++;
        }
      }
    }

    showToast(`${savedCount} nota(s) guardada(s) correctamente`, 'success');
    setEditingStudent('');
    loadGrades();
  };

  if (loading) {
    return <div className="bg-white rounded-xl border border-gray-200 p-8 text-center text-gray-400">Cargando notas...</div>;
  }

  const editingStudentData = editingStudent ? students.find((s) => s.id === editingStudent) : null;
  const editingSubjects = editingStudent ? studentEnrolledSubjects(editingStudent) : [];

  return (
    <div>
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-6">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Calificaciones</h2>
          <p className="text-sm text-gray-500 mt-0.5">Escala del 0 al 20 · 3 lapsos por año escolar</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button variant="outline" onClick={handleExportPDF}>
            <FileDown className="h-4 w-4" />
            Descargar PDF
          </Button>
          <Button variant="outline" onClick={handleExportExcel}>
            <FileSpreadsheet className="h-4 w-4" />
            Descargar Excel
          </Button>
        </div>
      </div>

      <div className="flex flex-col sm:flex-row gap-3 mb-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input placeholder="Buscar estudiante..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-10 w-full" />
        </div>
        <Select value={filterYear} onChange={(e) => setFilterYear(e.target.value === 'all' ? 'all' : Number(e.target.value))} className="sm:w-36">
          <option value="all">Todos los años</option>
          {SCHOOL_YEARS.map((y) => <option key={y.value} value={y.value}>{y.label}</option>)}
        </Select>
        <Select value={filterSection} onChange={(e) => setFilterSection(e.target.value === 'all' ? 'all' : e.target.value)} className="sm:w-36">
          <option value="all">Todas las secciones</option>
          {[...new Set(students.map((s) => s.section).filter(Boolean))].sort().map((s) => <option key={s} value={s}>Sección {s}</option>)}
        </Select>
        <Select value={selectedLapso} onChange={(e) => setSelectedLapso(Number(e.target.value))} className="sm:w-32">
          {LAPSO_OPTIONS.map((l) => <option key={l.value} value={l.value}>{l.label}</option>)}
        </Select>
      </div>

      {filteredStudents.length === 0 ? (
        <div className="bg-white rounded-xl border border-gray-200">
          <EmptyState icon={<FileText className="h-8 w-8" />} title="No hay estudiantes" description="Registra estudiantes para gestionar sus notas." />
        </div>
      ) : (
        <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-200 bg-gray-50 text-left">
                  <th className="px-4 py-3 font-semibold text-gray-600 whitespace-nowrap">Estudiante</th>
                  <th className="px-4 py-3 font-semibold text-gray-600 whitespace-nowrap">Año</th>
                  <th className="px-4 py-3 font-semibold text-gray-600 whitespace-nowrap">Materias</th>
                  <th className="px-4 py-3 font-semibold text-gray-600 whitespace-nowrap">{LAPSO_OPTIONS.find((l) => l.value === selectedLapso)?.label}</th>
                  <th className="px-4 py-3 font-semibold text-gray-600 whitespace-nowrap">Promedio</th>
                  <th className="px-4 py-3 font-semibold text-gray-600 text-right">Acción</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {filteredStudents.map((student) => {
                  const subjCount = studentEnrolledSubjects(student.id).length;
                  const lapsoGrades = studentEnrolledSubjects(student.id).map((s) => getGrade(student.id, s.id, selectedLapso)).filter((g) => g !== null) as number[];
                  const lapsoAvg = lapsoGrades.length > 0 ? (lapsoGrades.reduce((a, b) => a + b, 0) / lapsoGrades.length).toFixed(1) : '—';
                  return (
                    <tr key={student.id} className="hover:bg-gray-50 transition-colors">
                      <td className="px-4 py-3 whitespace-nowrap">
                        <p className="text-gray-900 font-medium">{fullName(student.first_name, student.last_name)}</p>
                        <p className="text-xs text-gray-500">C.I: {student.cedula}</p>
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap">{yearLabel(student.school_year)}</td>
                      <td className="px-4 py-3 whitespace-nowrap">
                        <Badge color={subjCount > 0 ? 'blue' : 'gray'}>{subjCount}</Badge>
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap">
                        {lapsoGrades.length > 0 ? (
                          <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${gradeBg(Number(lapsoAvg))}`}>
                            {lapsoAvg}
                          </span>
                        ) : (
                          <span className="text-gray-400">—</span>
                        )}
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap">
                        <span className={`text-sm font-medium ${gradeColor(Number(getAverage(student.id)))}`}>
                          {getAverage(student.id)}
                        </span>
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap text-right">
                        <div className="flex items-center justify-end gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => openGradeEditor(student.id)}
                            disabled={subjCount === 0}
                          >
                            <FileText className="h-3.5 w-3.5" />
                            Editar
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => setBoletinStudent(student)}
                          >
                            <ScrollText className="h-3.5 w-3.5" />
                            Boletín
                          </Button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Grade Editor Modal */}
      {editingStudentData && (
        <div className="fixed inset-0 z-[80] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={() => setEditingStudent('')} />
          <div className="relative z-10 w-full max-w-3xl max-h-[90vh] overflow-hidden rounded-2xl bg-white shadow-2xl animate-fade-in-up flex flex-col">
            <div className="flex items-center justify-between border-b border-gray-100 px-6 py-4 flex-shrink-0">
              <div>
                <h3 className="text-lg font-semibold text-gray-900">Notas - {fullName(editingStudentData.first_name, editingStudentData.last_name)}</h3>
                <p className="text-xs text-gray-500">{yearLabel(editingStudentData.school_year)} · Sección {editingStudentData.section}</p>
              </div>
              <button onClick={() => setEditingStudent('')} className="text-gray-400 hover:text-gray-600">
                <span className="text-2xl">×</span>
              </button>
            </div>
            <div className="overflow-y-auto px-6 py-5">
              {editingSubjects.length === 0 ? (
                <p className="text-sm text-gray-400 text-center py-8">El estudiante no tiene materias inscritas.</p>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-gray-200 text-left">
                        <th className="px-3 py-2 font-semibold text-gray-600 whitespace-nowrap">Materia</th>
                        {LAPSO_OPTIONS.map((l) => (
                          <th key={l.value} className="px-3 py-2 font-semibold text-gray-600 text-center whitespace-nowrap w-24">{l.label}</th>
                        ))}
                        <th className="px-3 py-2 font-semibold text-gray-600 text-center whitespace-nowrap">Final</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100">
                      {editingSubjects.map((subj) => {
                        const l1 = parseFloat(editValues[`${subj.id}-1`] || '');
                        const l2 = parseFloat(editValues[`${subj.id}-2`] || '');
                        const l3 = parseFloat(editValues[`${subj.id}-3`] || '');
                        const valid = [l1, l2, l3].filter((n) => !isNaN(n));
                        const final = valid.length > 0 ? (valid.reduce((a, b) => a + b, 0) / valid.length).toFixed(2) : '—';
                        return (
                          <tr key={subj.id}>
                            <td className="px-3 py-2.5 text-gray-900 whitespace-nowrap">{subj.name}</td>
                            {LAPSO_OPTIONS.map((l) => (
                              <td key={l.value} className="px-3 py-2.5 text-center">
                                <Input
                                  value={editValues[`${subj.id}-${l.value}`] || ''}
                                  onChange={(e) => handleGradeChange(subj.id, l.value, e.target.value)}
                                  placeholder="—"
                                  className="w-20 text-center"
                                  maxLength={5}
                                />
                              </td>
                            ))}
                            <td className="px-3 py-2.5 text-center">
                              <span className={`text-sm font-bold ${gradeColor(Number(final))}`}>{final}</span>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
              <div className="mt-4 rounded-lg bg-blue-50 p-3 text-xs text-blue-700">
                <p><strong>Escala de evaluación:</strong> 0 a 20 puntos. Aprobado: 10 o más. Lapso final = promedio de los 3 lapsos.</p>
              </div>
            </div>
            <div className="flex justify-end gap-3 border-t border-gray-100 px-6 py-4 flex-shrink-0">
              <Button variant="outline" onClick={() => setEditingStudent('')}>Cancelar</Button>
              <Button onClick={handleSaveGrades}><Save className="h-4 w-4" /> Guardar Notas</Button>
            </div>
          </div>
        </div>
      )}

      {/* Boletín Modal */}
      {boletinStudent && (
        <BoletinModal
          student={boletinStudent}
          subjects={subjects}
          grades={grades}
          representative={representatives.find((r) => r.id === boletinStudent.representative_id) || null}
          onClose={() => setBoletinStudent(null)}
        />
      )}
    </div>
  );
}
