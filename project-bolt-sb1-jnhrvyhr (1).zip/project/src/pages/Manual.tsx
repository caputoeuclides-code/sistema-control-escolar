import { useState } from 'react';
import { Button } from '@/components/ui';
import {
  HelpCircle, BookOpen, Users, UserCog, UserCheck, ClipboardList, FileText,
  Code2, ShieldAlert, Download, ChevronDown, ChevronRight, School,
  CheckCircle2, Database,
} from 'lucide-react';

interface ManualSection {
  id: string;
  title: string;
  icon: typeof Users;
  content: string[];
}

const SECTIONS: ManualSection[] = [
  {
    id: 'intro',
    title: 'Introducción',
    icon: School,
    content: [
      'El Sistema de Control Escolar es una plataforma diseñada para la gestión integral de instituciones de educación secundaria en Venezuela (1ro a 5to año).',
      'Permite administrar estudiantes, profesores, representantes, materias, inscripciones y notas en un solo lugar, con una interfaz responsiva que se adapta a móviles, tablets y computadoras.',
      'El sistema utiliza una base de datos segura en la nube (Supabase) que garantiza la persistencia y disponibilidad de los datos en todo momento.',
    ],
  },
  {
    id: 'estudiantes',
    title: 'Gestión de Estudiantes',
    icon: Users,
    content: [
      'Registra estudiantes con cédula de identidad, nombres, apellidos, fecha de nacimiento, género, año escolar (1ro a 5to), sección y datos de contacto.',
      'Cada estudiante puede ser vinculado a un representante previamente registrado en el sistema.',
      'El campo de cédula y teléfono solo aceptan dígitos numéricos, bloqueando automáticamente letras y caracteres especiales.',
      'Marca un estudiante como "Repetidor" para activar el seguimiento de asignaturas pendientes. Al hacerlo, podrás seleccionar las materias pendientes de años anteriores.',
      'El sistema muestra alertas visuales (ícono de advertencia) en la tabla de estudiantes para identificar rápidamente a los repetidores y aquellos con materias pendientes.',
      'Usa la barra de búsqueda para encontrar estudiantes por nombre o cédula, y el filtro por año para ver estudiantes de un año específico.',
    ],
  },
  {
    id: 'profesores',
    title: 'Gestión de Profesores',
    icon: UserCog,
    content: [
      'Registra los profesores del plantel con su cédula, datos personales, teléfono, email y especialidad.',
      'La cédula y teléfono validan que solo se ingresen dígitos numéricos.',
      'Puedes editar o eliminar profesores usando los botones de acción en la tabla.',
    ],
  },
  {
    id: 'representantes',
    title: 'Gestión de Representantes',
    icon: UserCheck,
    content: [
      'Registra los representantes (padres, madres, tutores) con cédula, nombres, apellidos, teléfono, email, parentesco y dirección.',
      'Los representantes pueden ser vinculados a uno o más estudiantes desde el módulo de Estudiantes.',
      'Los campos de cédula y teléfono solo aceptan números.',
    ],
  },
  {
    id: 'materias',
    title: 'Gestión de Materias',
    icon: BookOpen,
    content: [
      'Registra las materias del pensum educativo organizadas por año escolar (1ro a 5to año).',
      'Cada materia tiene nombre, código opcional y año al que pertenece.',
      'Las materias se muestran agrupadas por año para facilitar la visualización del pensum completo.',
      'Usa el filtro por año para ver las materias de un año específico.',
    ],
  },
  {
    id: 'inscripciones',
    title: 'Inscripciones',
    icon: ClipboardList,
    content: [
      'Inscribe estudiantes en materias mediante un modal interactivo con casillas de verificación (checkboxes).',
      'Al seleccionar un estudiante, el sistema pre-selecciona automáticamente las materias correspondientes a su año escolar.',
      'Si el estudiante es repetidor o tiene asignaturas pendientes, estas se muestran destacadas en rojo y se pre-seleccionan para su inscripción.',
      'Puedes inscribir materias de otros años si es necesario (por ejemplo, para estudiantes que necesitan recuperar materias).',
      'Las materias ya inscritas se muestran con un ícono verde de confirmación y no se pueden duplicar.',
      'Para retirar una materia, haz clic en el ícono X junto al nombre de la materia en la lista del estudiante.',
    ],
  },
  {
    id: 'notas',
    title: 'Registro de Notas',
    icon: FileText,
    content: [
      'El sistema utiliza la escala venezolana de evaluación de 0 a 20 puntos, con 3 lapsos por año escolar.',
      'La nota mínima aprobatoria es 10 puntos.',
      'Selecciona el lapso (I, II o III) para ver las notas de ese periodo en la tabla principal.',
      'Haz clic en "Editar" para abrir el editor de notas del estudiante, donde puedes ingresar las calificaciones de cada materia en cada lapso.',
      'El promedio final se calcula automáticamente como el promedio de los 3 lapsos.',
      'Las notas se muestran con código de color: verde (18-20), azul (14-17), amarillo (10-13) y rojo (menos de 10).',
    ],
  },
  {
    id: 'dev',
    title: 'Módulo DEV',
    icon: Code2,
    content: [
      'EXPORTAR: Descarga una copia de seguridad completa en formato JSON con todos los datos del sistema.',
      'IMPORTAR: Restaura la base de datos desde un archivo JSON previamente exportado. Esta acción reemplaza todos los datos actuales.',
      'ZONA DE PELIGRO: Permite el reseteo completo de la base de datos, eliminando todos los registros permanentemente.',
      'El reseteo requiere doble confirmación: primero debes hacer clic en "Resetear Base de Datos" y luego escribir la palabra "ELIMINAR" para habilitar el botón de confirmación final.',
      'Se recomienda exportar una copia de seguridad antes de realizar cualquier operación de importación o reseteo.',
    ],
  },
  {
    id: 'validaciones',
    title: 'Validaciones del Sistema',
    icon: ShieldAlert,
    content: [
      'Cédula de Identidad: Solo se permiten dígitos numéricos (0-9). Se bloquean letras y caracteres especiales automáticamente.',
      'Teléfonos: Solo se permiten dígitos numéricos (0-9).',
      'Notas: Solo se aceptan valores entre 0 y 20. Cualquier valor fuera de este rango se ajusta automáticamente.',
      'Cédulas duplicadas: El sistema no permite registrar dos estudiantes, profesores o representantes con la misma cédula.',
      'Inscripciones duplicadas: No se puede inscribir a un estudiante en la misma materia dos veces.',
    ],
  },
];

export function Manual() {
  const [expanded, setExpanded] = useState<string | null>('intro');

  const toggleSection = (id: string) => {
    setExpanded(expanded === id ? null : id);
  };

  const handlePrintPDF = () => {
    // Expand all sections before printing
    const original = expanded;
    setExpanded(null);
    setTimeout(() => {
      window.print();
      setExpanded(original);
    }, 100);
  };

  return (
    <div>
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-6 no-print">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <HelpCircle className="h-6 w-6 text-blue-600" />
            Manual de Usuario
          </h2>
          <p className="text-sm text-gray-500 mt-0.5">Guía completa de uso del Sistema de Control Escolar</p>
        </div>
        <Button variant="outline" onClick={handlePrintPDF}>
          <Download className="h-4 w-4" />
          Descargar PDF
        </Button>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
        {/* Manual header for print */}
        <div className="px-6 py-5 bg-gradient-to-r from-blue-600 to-blue-800 text-white print-block">
          <div className="flex items-center gap-3">
            <School className="h-8 w-8" />
            <div>
              <h1 className="text-xl font-bold">Sistema de Control Escolar</h1>
              <p className="text-sm text-blue-100">Manual de Usuario - Educación Secundaria Venezuela (1ro a 5to Año)</p>
            </div>
          </div>
        </div>

        <div className="divide-y divide-gray-100">
          {SECTIONS.map((section) => {
            const Icon = section.icon;
            const isOpen = expanded === section.id;
            return (
              <div key={section.id}>
                <button
                  onClick={() => toggleSection(section.id)}
                  className="w-full flex items-center gap-3 px-6 py-4 hover:bg-gray-50 transition-colors text-left no-print"
                >
                  <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-blue-100 text-blue-600 flex-shrink-0">
                    <Icon className="h-4 w-4" />
                  </div>
                  <span className="flex-1 font-medium text-gray-900 text-sm">{section.title}</span>
                  {isOpen ? <ChevronDown className="h-4 w-4 text-gray-400" /> : <ChevronRight className="h-4 w-4 text-gray-400" />}
                </button>

                {/* Print version - always visible */}
                <div className="hidden print-block px-6 py-4">
                  <div className="flex items-center gap-3 mb-2">
                    <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-blue-100 text-blue-600 flex-shrink-0">
                      <Icon className="h-4 w-4" />
                    </div>
                    <h3 className="font-semibold text-gray-900">{section.title}</h3>
                  </div>
                  <ul className="space-y-1.5 ml-11">
                    {section.content.map((line, i) => (
                      <li key={i} className="text-sm text-gray-600 flex items-start gap-2">
                        <span className="text-blue-500 mt-0.5">•</span>
                        <span>{line}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Screen version - collapsible */}
                {isOpen && (
                  <div className="px-6 pb-4 no-print">
                    <ul className="space-y-2 ml-11">
                      {section.content.map((line, i) => (
                        <li key={i} className="text-sm text-gray-600 flex items-start gap-2">
                          <CheckCircle2 className="h-4 w-4 text-blue-500 flex-shrink-0 mt-0.5" />
                          <span>{line}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 bg-gray-50 border-t border-gray-200">
          <div className="flex items-center gap-2 text-xs text-gray-500">
            <Database className="h-4 w-4" />
            <span>Sistema de Control Escolar v1.0 - Almacenamiento seguro en la nube con Supabase</span>
          </div>
        </div>
      </div>

      {/* Print styles */}
      <style>{`
        @media print {
          .no-print { display: none !important; }
          .print-block { display: block !important; }
          body { background: white !important; }
        }
        @media screen {
          .print-block { display: none; }
        }
      `}</style>
    </div>
  );
}
