import { useCallback, useEffect, useState } from 'react';
import { supabase, TABLES } from '@/lib/supabase';
import type { Representative } from '@/lib/types';
import { useToast } from '@/components/Toast';
import { ConfirmModal, Modal } from '@/components/Modal';
import { Button, EmptyState, FormField, Input } from '@/components/ui';
import { onlyDigits, fullName } from '@/lib/utils';
import { UserCheck, Plus, Pencil, Trash2, Search } from 'lucide-react';

export function Representatives() {
  const { showToast } = useToast();
  const [reps, setReps] = useState<Representative[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Representative | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<Representative | null>(null);
  const [form, setForm] = useState({
    cedula: '', first_name: '', last_name: '', phone: '', email: '', relationship: '', address: '',
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const load = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase.from(TABLES.REPRESENTATIVES).select('*').order('created_at', { ascending: false });
    if (error) { showToast('Error al cargar representantes', 'error'); }
    else { setReps(data as Representative[]); }
    setLoading(false);
  }, [showToast]);

  useEffect(() => { load(); }, [load]);

  const resetForm = () => {
    setForm({ cedula: '', first_name: '', last_name: '', phone: '', email: '', relationship: '', address: '' });
    setErrors({}); setEditing(null);
  };

  const openCreate = () => { resetForm(); setModalOpen(true); };

  const openEdit = (r: Representative) => {
    setEditing(r);
    setForm({ cedula: r.cedula, first_name: r.first_name, last_name: r.last_name, phone: r.phone || '', email: r.email || '', relationship: r.relationship || '', address: r.address || '' });
    setErrors({}); setModalOpen(true);
  };

  const validate = (): boolean => {
    const e: Record<string, string> = {};
    if (!form.cedula.trim()) e.cedula = 'La cédula es obligatoria';
    if (!form.first_name.trim()) e.first_name = 'El nombre es obligatorio';
    if (!form.last_name.trim()) e.last_name = 'El apellido es obligatorio';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = async () => {
    if (!validate()) return;
    const payload = {
      cedula: form.cedula.trim(), first_name: form.first_name.trim(), last_name: form.last_name.trim(),
      phone: form.phone, email: form.email, relationship: form.relationship, address: form.address,
    };
    if (editing) {
      const { error } = await supabase.from(TABLES.REPRESENTATIVES).update(payload).eq('id', editing.id);
      if (error) { showToast(error.message.includes('duplicate') ? 'Ya existe un representante con esa cédula' : 'Error al actualizar', 'error'); return; }
      showToast('Representante actualizado correctamente', 'success');
    } else {
      const { error } = await supabase.from(TABLES.REPRESENTATIVES).insert(payload);
      if (error) { showToast(error.message.includes('duplicate') ? 'Ya existe un representante con esa cédula' : 'Error al crear representante', 'error'); return; }
      showToast('Representante creado correctamente', 'success');
    }
    setModalOpen(false); resetForm(); load();
  };

  const handleDelete = async () => {
    if (!confirmDelete) return;
    const { error } = await supabase.from(TABLES.REPRESENTATIVES).delete().eq('id', confirmDelete.id);
    if (error) { showToast('Error al eliminar representante', 'error'); }
    else { showToast('Representante eliminado correctamente', 'success'); load(); }
    setConfirmDelete(null);
  };

  const filtered = reps.filter((r) => {
    const q = search.toLowerCase();
    return fullName(r.first_name, r.last_name).toLowerCase().includes(q) || r.cedula.includes(search);
  });

  return (
    <div>
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-6">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Representantes</h2>
          <p className="text-sm text-gray-500 mt-0.5">{reps.length} representantes registrados</p>
        </div>
        <Button onClick={openCreate}><Plus className="h-4 w-4" /> Nuevo Representante</Button>
      </div>

      <div className="relative mb-4">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
        <Input placeholder="Buscar por nombre o cédula..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-10 w-full" />
      </div>

      <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
        {loading ? (
          <div className="p-8 text-center text-gray-400">Cargando...</div>
        ) : filtered.length === 0 ? (
          <EmptyState
            icon={<UserCheck className="h-8 w-8" />}
            title="No hay representantes"
            description="Registra el primer representante del sistema."
            action={<Button onClick={openCreate}><Plus className="h-4 w-4" /> Nuevo Representante</Button>}
          />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-200 bg-gray-50 text-left">
                  <th className="px-4 py-3 font-semibold text-gray-600 whitespace-nowrap">Cédula</th>
                  <th className="px-4 py-3 font-semibold text-gray-600 whitespace-nowrap">Nombre</th>
                  <th className="px-4 py-3 font-semibold text-gray-600 whitespace-nowrap">Teléfono</th>
                  <th className="px-4 py-3 font-semibold text-gray-600 whitespace-nowrap">Email</th>
                  <th className="px-4 py-3 font-semibold text-gray-600 whitespace-nowrap">Parentesco</th>
                  <th className="px-4 py-3 font-semibold text-gray-600 whitespace-nowrap">Dirección</th>
                  <th className="px-4 py-3 font-semibold text-gray-600 text-right">Acciones</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {filtered.map((r) => (
                  <tr key={r.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-4 py-3 font-mono text-xs text-gray-700 whitespace-nowrap">{r.cedula}</td>
                    <td className="px-4 py-3 text-gray-900 whitespace-nowrap">{fullName(r.first_name, r.last_name)}</td>
                    <td className="px-4 py-3 text-gray-600 whitespace-nowrap">{r.phone || '—'}</td>
                    <td className="px-4 py-3 text-gray-600 whitespace-nowrap">{r.email || '—'}</td>
                    <td className="px-4 py-3 text-gray-600 whitespace-nowrap">{r.relationship || '—'}</td>
                    <td className="px-4 py-3 text-gray-600 max-w-xs truncate">{r.address || '—'}</td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      <div className="flex items-center justify-end gap-2">
                        <button onClick={() => openEdit(r)} className="p-1.5 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors">
                          <Pencil className="h-4 w-4" />
                        </button>
                        <button onClick={() => setConfirmDelete(r)} className="p-1.5 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors">
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <Modal
        open={modalOpen}
        title={editing ? 'Editar Representante' : 'Nuevo Representante'}
        onClose={() => { setModalOpen(false); resetForm(); }}
        size="md"
      >
        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <FormField label="Cédula de Identidad" required error={errors.cedula}>
              <Input value={form.cedula} onChange={(e) => setForm({ ...form, cedula: onlyDigits(e.target.value) })} placeholder="Ej: 12345678" invalid={!!errors.cedula} maxLength={10} />
            </FormField>
            <FormField label="Teléfono">
              <Input value={form.phone} onChange={(e) => setForm({ ...form, phone: onlyDigits(e.target.value) })} placeholder="Ej: 04141234567" maxLength={15} />
            </FormField>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <FormField label="Nombres" required error={errors.first_name}>
              <Input value={form.first_name} onChange={(e) => setForm({ ...form, first_name: e.target.value })} placeholder="Nombres" invalid={!!errors.first_name} />
            </FormField>
            <FormField label="Apellidos" required error={errors.last_name}>
              <Input value={form.last_name} onChange={(e) => setForm({ ...form, last_name: e.target.value })} placeholder="Apellidos" invalid={!!errors.last_name} />
            </FormField>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <FormField label="Email">
              <Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="representante@email.com" />
            </FormField>
            <FormField label="Parentesco (opcional)">
              <Input value={form.relationship} onChange={(e) => setForm({ ...form, relationship: e.target.value })} placeholder="Ej: Padre, Madre, Tío/a..." />
            </FormField>
          </div>
          <FormField label="Dirección">
            <Input value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} placeholder="Dirección de habitación" />
          </FormField>
          <div className="flex justify-end gap-3 pt-2 border-t border-gray-100">
            <Button variant="outline" onClick={() => { setModalOpen(false); resetForm(); }}>Cancelar</Button>
            <Button onClick={handleSubmit}>{editing ? 'Guardar Cambios' : 'Crear Representante'}</Button>
          </div>
        </div>
      </Modal>

      <ConfirmModal
        open={!!confirmDelete}
        title="Eliminar Representante"
        message={`¿Estás seguro de eliminar a ${confirmDelete ? fullName(confirmDelete.first_name, confirmDelete.last_name) : ''}?`}
        confirmText="Eliminar"
        onConfirm={handleDelete}
        onCancel={() => setConfirmDelete(null)}
      />
    </div>
  );
}
