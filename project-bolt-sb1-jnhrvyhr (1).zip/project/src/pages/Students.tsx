import { useCallback, useEffect, useState } from 'react';
import { supabase, TABLES, SCHOOL_YEARS } from '@/lib/supabase';
import type { Representative, Student, Subject } from '@/lib/types';
import { useToast } from '@/components/Toast';
import { ConfirmModal, Modal } from '@/components/Modal';
import { Badge, Button, EmptyState, FormField, Input, Select } from '@/components/ui';
import { onlyDigits, fullName, yearLabel } from '@/lib/utils';
import {
  Users, Plus, Pencil, Trash2, Search, AlertTriangle, FileDown, FileSpreadsheet,
} from 'lucide-react';
import { exportStudentsPDF, exportStudentsExcel } from '@/lib/exportReports';

interface StudentsProps {
  representatives: Representative[];
  subjects: Subject[];
}

export function Students({ representatives, subjects }: StudentsProps) {
  const { showToast } = useToast();
  const [students, setStudents] = useState<Student[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filterYear, setFilterYear] = useState<number | 'all'>('all');
  const [filterSection, setFilterSection] = useState<string | 'all'>('all');
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Student | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<Student | null>(null);
  const [form, setForm] = useState({
    cedula: '',
    first_name: '',
    last_name: '',
    birth_date: '',
    gender: 'M',
    school_year: 1,
    section: 'A',
    representative_id: '',
    phone: '',
    address: '',
    is_repeating: false,
    pending_subjects: [] as string[],
    status: 'activo',
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const loadStudents = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase.from(TABLES.STUDENTS).select('*').order('created_at', { ascending: false });
    if (error) {
      showToast('Error al cargar estudiantes', 'error');
    } else {
      setStudents(data as Student[]);
    }
    setLoading(false);
  }, [showToast]);

  useEffect(() => {
    loadStudents();
  }, [loadStudents]);

  const resetForm = () => {
    setForm({
      cedula: '', first_name: '', last_name: '', birth_date: '',
      gender: 'M', school_year: 1, section: 'A', representative_id: '',
      phone: '', address: '', is_repeating: false, pending_subjects: [], status: 'activo',
    });
    setErrors({});
    setEditing(null);
  };

  const openCreate = () => {
    resetForm();
    setModalOpen(true);
  };

  const openEdit = (student: Student) => {
    setEditing(student);
    setForm({
      cedula: student.cedula,
      first_name: student.first_name,
      last_name: student.last_name,
      birth_date: student.birth_date || '',
      gender: student.gender,
      school_year: student.school_year,
      section: student.section,
      representative_id: student.representative_id || '',
      phone: student.phone || '',
      address: student.address || '',
      is_repeating: student.is_repeating,
      pending_subjects: student.pending_subjects || [],
      status: student.status,
    });
    setErrors({});
    setModalOpen(true);
  };

  const validate = (): boolean => {
    const e: Record<string, string> = {};
    if (!form.cedula.trim()) e.cedula = 'La cédula es obligatoria';
    if (!form.first_name.trim()) e.first_name = 'El nombre es obligatorio';
    if (!form.last_name.trim()) e.last_name = 'El apellido es obligatorio';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = async () => {
    if (!validate()) return;
    const payload = {
      cedula: form.cedula.trim(),
      first_name: form.first_name.trim(),
      last_name: form.last_name.trim(),
      birth_date: form.birth_date || null,
      gender: form.gender,
      school_year: form.school_year,
      section: form.section,
      representative_id: form.representative_id || null,
      phone: form.phone,
      address: form.address,
      is_repeating: form.is_repeating,
      pending_subjects: form.pending_subjects,
      status: form.status,
    };

    if (editing) {
      const { error } = await supabase.from(TABLES.STUDENTS).update(payload).eq('id', editing.id);
      if (error) {
        showToast(error.message.includes('duplicate') ? 'Ya existe un estudiante con esa cédula' : 'Error al actualizar', 'error');
        return;
      }
      showToast('Estudiante actualizado correctamente', 'success');
    } else {
      const { error } = await supabase.from(TABLES.STUDENTS).insert(payload);
      if (error) {
        showToast(error.message.includes('duplicate') ? 'Ya existe un estudiante con esa cédula' : 'Error al crear estudiante', 'error');
        return;
      }
      showToast('Estudiante creado correctamente', 'success');
    }
    setModalOpen(false);
    resetForm();
    loadStudents();
  };

  const handleDelete = async () => {
    if (!confirmDelete) return;
    const { error } = await supabase.from(TABLES.STUDENTS).delete().eq('id', confirmDelete.id);
    if (error) {
      showToast('Error al eliminar estudiante', 'error');
    } else {
      showToast('Estudiante eliminado correctamente', 'success');
      loadStudents();
    }
    setConfirmDelete(null);
  };

  const togglePendingSubject = (subjectId: string) => {
    setForm((prev) => ({
      ...prev,
      pending_subjects: prev.pending_subjects.includes(subjectId)
        ? prev.pending_subjects.filter((s) => s !== subjectId)
        : [...prev.pending_subjects, subjectId],
    }));
  };

  const filtered = students.filter((s) => {
    const matchesSearch =
      fullName(s.first_name, s.last_name).toLowerCase().includes(search.toLowerCase()) ||
      s.cedula.includes(search);
    const matchesYear = filterYear === 'all' || s.school_year === filterYear;
    const matchesSection = filterSection === 'all' || s.section === filterSection;
    return matchesSearch && matchesYear && matchesSection;
  });

  const handleExportPDF = () => {
    if (filtered.length === 0) {
      showToast('No hay estudiantes para exportar con los filtros actuales', 'warning');
      return;
    }
    exportStudentsPDF({
      students: filtered,
      representatives,
      yearFilter: filterYear,
      sectionFilter: filterSection,
    });
    showToast('PDF descargado correctamente', 'success');
  };

  const handleExportExcel = () => {
    if (filtered.length === 0) {
      showToast('No hay estudiantes para exportar con los filtros actuales', 'warning');
      return;
    }
    exportStudentsExcel({
      students: filtered,
      representatives,
      yearFilter: filterYear,
      sectionFilter: filterSection,
    });
    showToast('Excel descargado correctamente', 'success');
  };

  const repName = (id: string | null) => {
    if (!id) return '—';
    const r = representatives.find((rep) => rep.id === id);
    return r ? fullName(r.first_name, r.last_name) : '—';
  };

  const pendingSubjectNames = (ids: string[]) => {
    return ids.map((id) => subjects.find((s) => s.id === id)?.name).filter(Boolean) as string[];
  };

  return (
    <div>
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-6">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Estudiantes</h2>
          <p className="text-sm text-gray-500 mt-0.5">{students.length} estudiantes registrados</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button variant="outline" onClick={handleExportPDF}>
            <FileDown className="h-4 w-4" />
            Descargar PDF
          </Button>
          <Button variant="outline" onClick={handleExportExcel}>
            <FileSpreadsheet className="h-4 w-4" />
            Descargar Excel
          </Button>
          <Button onClick={openCreate}>
            <Plus className="h-4 w-4" />
            Nuevo Estudiante
          </Button>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3 mb-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input
            placeholder="Buscar por nombre o cédula..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10 w-full"
          />
        </div>
        <Select
          value={filterYear}
          onChange={(e) => setFilterYear(e.target.value === 'all' ? 'all' : Number(e.target.value))}
          className="sm:w-36"
        >
          <option value="all">Todos los años</option>
          {SCHOOL_YEARS.map((y) => (
            <option key={y.value} value={y.value}>{y.label}</option>
          ))}
        </Select>
        <Select
          value={filterSection}
          onChange={(e) => setFilterSection(e.target.value === 'all' ? 'all' : e.target.value)}
          className="sm:w-36"
        >
          <option value="all">Todas las secciones</option>
          {[...new Set(students.map((s) => s.section).filter(Boolean))].sort().map((s) => (
            <option key={s} value={s}>Sección {s}</option>
          ))}
        </Select>
      </div>

      {/* Table */}
      <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
        {loading ? (
          <div className="p-8 text-center text-gray-400">Cargando...</div>
        ) : filtered.length === 0 ? (
          <EmptyState
            icon={<Users className="h-8 w-8" />}
            title="No hay estudiantes"
            description="Comienza registrando el primer estudiante del sistema."
            action={<Button onClick={openCreate}><Plus className="h-4 w-4" /> Nuevo Estudiante</Button>}
          />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-200 bg-gray-50 text-left">
                  <th className="px-4 py-3 font-semibold text-gray-600 whitespace-nowrap">Cédula</th>
                  <th className="px-4 py-3 font-semibold text-gray-600 whitespace-nowrap">Nombre</th>
                  <th className="px-4 py-3 font-semibold text-gray-600 whitespace-nowrap">Año</th>
                  <th className="px-4 py-3 font-semibold text-gray-600 whitespace-nowrap">Sección</th>
                  <th className="px-4 py-3 font-semibold text-gray-600 whitespace-nowrap">Representante</th>
                  <th className="px-4 py-3 font-semibold text-gray-600 whitespace-nowrap">Estado</th>
                  <th className="px-4 py-3 font-semibold text-gray-600 whitespace-nowrap">Pendientes</th>
                  <th className="px-4 py-3 font-semibold text-gray-600 text-right">Acciones</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {filtered.map((student) => (
                  <tr key={student.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-4 py-3 font-mono text-xs text-gray-700 whitespace-nowrap">{student.cedula}</td>
                    <td className="px-4 py-3 text-gray-900 whitespace-nowrap">{fullName(student.first_name, student.last_name)}</td>
                    <td className="px-4 py-3 whitespace-nowrap">{yearLabel(student.school_year)}</td>
                    <td className="px-4 py-3 whitespace-nowrap">{student.section}</td>
                    <td className="px-4 py-3 text-gray-600 whitespace-nowrap">{repName(student.representative_id)}</td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      <Badge color={student.status === 'activo' ? 'green' : 'gray'}>
                        {student.status === 'activo' ? 'Activo' : 'Inactivo'}
                      </Badge>
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      {student.is_repeating || (student.pending_subjects && student.pending_subjects.length > 0) ? (
                        <div className="flex items-center gap-1">
                          <AlertTriangle className="h-4 w-4 text-amber-500" />
                          {student.pending_subjects?.length > 0 && (
                            <span className="text-xs text-amber-600">{student.pending_subjects.length} pendiente(s)</span>
                          )}
                          {student.is_repeating && <Badge color="amber">Repetidor</Badge>}
                        </div>
                      ) : (
                        <span className="text-gray-400">—</span>
                      )}
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      <div className="flex items-center justify-end gap-2">
                        <button
                          onClick={() => openEdit(student)}
                          className="p-1.5 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                        >
                          <Pencil className="h-4 w-4" />
                        </button>
                        <button
                          onClick={() => setConfirmDelete(student)}
                          className="p-1.5 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Create/Edit Modal */}
      <Modal
        open={modalOpen}
        title={editing ? 'Editar Estudiante' : 'Nuevo Estudiante'}
        onClose={() => { setModalOpen(false); resetForm(); }}
        size="lg"
      >
        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <FormField label="Cédula de Identidad" required error={errors.cedula}>
              <Input
                value={form.cedula}
                onChange={(e) => setForm({ ...form, cedula: onlyDigits(e.target.value) })}
                placeholder="Ej: 12345678"
                invalid={!!errors.cedula}
                maxLength={10}
              />
            </FormField>
            <FormField label="Teléfono">
              <Input
                value={form.phone}
                onChange={(e) => setForm({ ...form, phone: onlyDigits(e.target.value) })}
                placeholder="Ej: 04141234567"
                maxLength={15}
              />
            </FormField>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <FormField label="Nombres" required error={errors.first_name}>
              <Input
                value={form.first_name}
                onChange={(e) => setForm({ ...form, first_name: e.target.value })}
                placeholder="Nombres del estudiante"
                invalid={!!errors.first_name}
              />
            </FormField>
            <FormField label="Apellidos" required error={errors.last_name}>
              <Input
                value={form.last_name}
                onChange={(e) => setForm({ ...form, last_name: e.target.value })}
                placeholder="Apellidos del estudiante"
                invalid={!!errors.last_name}
              />
            </FormField>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <FormField label="Fecha de Nacimiento">
              <Input
                type="date"
                value={form.birth_date}
                onChange={(e) => setForm({ ...form, birth_date: e.target.value })}
              />
            </FormField>
            <FormField label="Género">
              <Select
                value={form.gender}
                onChange={(e) => setForm({ ...form, gender: e.target.value })}
              >
                <option value="M">Masculino</option>
                <option value="F">Femenino</option>
              </Select>
            </FormField>
            <FormField label="Estado">
              <Select
                value={form.status}
                onChange={(e) => setForm({ ...form, status: e.target.value })}
              >
                <option value="activo">Activo</option>
                <option value="inactivo">Inactivo</option>
              </Select>
            </FormField>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <FormField label="Año Escolar">
              <Select
                value={form.school_year}
                onChange={(e) => setForm({ ...form, school_year: Number(e.target.value) })}
              >
                {SCHOOL_YEARS.map((y) => (
                  <option key={y.value} value={y.value}>{y.label}</option>
                ))}
              </Select>
            </FormField>
            <FormField label="Sección">
              <Input
                value={form.section}
                onChange={(e) => setForm({ ...form, section: e.target.value })}
                placeholder="Ej: A, B, Única..."
                list="existing-sections"
              />
              <datalist id="existing-sections">
                {[...new Set(students.map((s) => s.section).filter(Boolean))].sort().map((s) => (
                  <option key={s} value={s} />
                ))}
              </datalist>
            </FormField>
            <FormField label="Representante">
              <Select
                value={form.representative_id}
                onChange={(e) => setForm({ ...form, representative_id: e.target.value })}
              >
                <option value="">Sin representante</option>
                {representatives.map((r) => (
                  <option key={r.id} value={r.id}>
                    {fullName(r.first_name, r.last_name)} - {r.cedula}
                  </option>
                ))}
              </Select>
            </FormField>
          </div>

          <FormField label="Dirección">
            <Input
              value={form.address}
              onChange={(e) => setForm({ ...form, address: e.target.value })}
              placeholder="Dirección de habitación"
            />
          </FormField>

          {/* Repeating & Pending subjects */}
          <div className="rounded-lg border border-gray-200 p-4 space-y-3">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={form.is_repeating}
                onChange={(e) => setForm({ ...form, is_repeating: e.target.checked })}
                className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
              />
              <span className="text-sm font-medium text-gray-700">Estudiante repetidor</span>
            </label>

            {form.is_repeating && (
              <div className="rounded-md bg-amber-50 border border-amber-200 p-3">
                <div className="flex items-center gap-2 mb-2">
                  <AlertTriangle className="h-4 w-4 text-amber-600" />
                  <span className="text-sm font-medium text-amber-800">Asignaturas Pendientes</span>
                </div>
                <p className="text-xs text-amber-700 mb-3">Selecciona las materias que el estudiante tiene pendientes de años anteriores:</p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-48 overflow-y-auto">
                  {subjects.length === 0 ? (
                    <p className="text-xs text-amber-600 col-span-2">No hay materias registradas. Registra materias primero.</p>
                  ) : (
                    subjects.map((subject) => (
                      <label key={subject.id} className="flex items-center gap-2 cursor-pointer text-sm">
                        <input
                          type="checkbox"
                          checked={form.pending_subjects.includes(subject.id)}
                          onChange={() => togglePendingSubject(subject.id)}
                          className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                        />
                        <span className="text-gray-700">{subject.name} ({yearLabel(subject.school_year)})</span>
                      </label>
                    ))
                  )}
                </div>
              </div>
            )}
          </div>

          <div className="flex justify-end gap-3 pt-2 border-t border-gray-100">
            <Button variant="outline" onClick={() => { setModalOpen(false); resetForm(); }}>
              Cancelar
            </Button>
            <Button onClick={handleSubmit}>
              {editing ? 'Guardar Cambios' : 'Crear Estudiante'}
            </Button>
          </div>
        </div>
      </Modal>

      {/* Delete confirmation */}
      <ConfirmModal
        open={!!confirmDelete}
        title="Eliminar Estudiante"
        message={`¿Estás seguro de eliminar a ${confirmDelete ? fullName(confirmDelete.first_name, confirmDelete.last_name) : ''}? Esta acción también eliminará sus inscripciones y notas asociadas.`}
        confirmText="Eliminar"
        onConfirm={handleDelete}
        onCancel={() => setConfirmDelete(null)}
      />
    </div>
  );
}
