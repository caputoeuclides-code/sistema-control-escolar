import { useCallback, useEffect, useState } from 'react';
import { supabase, TABLES, SCHOOL_YEARS } from '@/lib/supabase';
import type { Subject, Teacher } from '@/lib/types';
import { useToast } from '@/components/Toast';
import { ConfirmModal, Modal } from '@/components/Modal';
import { Badge, Button, EmptyState, FormField, Input, Select } from '@/components/ui';
import { yearLabel, fullName } from '@/lib/utils';
import { BookOpen, Plus, Pencil, Trash2, Search } from 'lucide-react';

export function Subjects() {
  const { showToast } = useToast();
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [teachers, setTeachers] = useState<Teacher[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filterYear, setFilterYear] = useState<number | 'all'>('all');
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Subject | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<Subject | null>(null);
  const [form, setForm] = useState({ name: '', code: '', school_year: 1, teacher_id: '' });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const load = useCallback(async () => {
    setLoading(true);
    const [subjRes, teachRes] = await Promise.all([
      supabase.from(TABLES.SUBJECTS).select('*').order('school_year', { ascending: true }).order('name', { ascending: true }),
      supabase.from(TABLES.TEACHERS).select('*').order('created_at', { ascending: false }),
    ]);
    if (subjRes.error) { showToast('Error al cargar materias', 'error'); }
    else { setSubjects(subjRes.data as Subject[]); }
    if (!teachRes.error) { setTeachers(teachRes.data as Teacher[]); }
    setLoading(false);
  }, [showToast]);

  useEffect(() => { load(); }, [load]);

  const resetForm = () => { setForm({ name: '', code: '', school_year: 1, teacher_id: '' }); setErrors({}); setEditing(null); };
  const openCreate = () => { resetForm(); setModalOpen(true); };
  const openEdit = (s: Subject) => {
    setEditing(s);
    setForm({ name: s.name, code: s.code || '', school_year: s.school_year, teacher_id: s.teacher_id || '' });
    setErrors({}); setModalOpen(true);
  };

  const validate = (): boolean => {
    const e: Record<string, string> = {};
    if (!form.name.trim()) e.name = 'El nombre es obligatorio';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = async () => {
    if (!validate()) return;
    const payload = { name: form.name.trim(), code: form.code.trim(), school_year: form.school_year, teacher_id: form.teacher_id || null };
    if (editing) {
      const { error } = await supabase.from(TABLES.SUBJECTS).update(payload).eq('id', editing.id);
      if (error) { showToast('Error al actualizar materia', 'error'); return; }
      showToast('Materia actualizada correctamente', 'success');
    } else {
      const { error } = await supabase.from(TABLES.SUBJECTS).insert(payload);
      if (error) { showToast('Error al crear materia', 'error'); return; }
      showToast('Materia creada correctamente', 'success');
    }
    setModalOpen(false); resetForm(); load();
  };

  const handleDelete = async () => {
    if (!confirmDelete) return;
    const { error } = await supabase.from(TABLES.SUBJECTS).delete().eq('id', confirmDelete.id);
    if (error) { showToast('Error al eliminar materia', 'error'); }
    else { showToast('Materia eliminada correctamente', 'success'); load(); }
    setConfirmDelete(null);
  };

  const filtered = subjects.filter((s) => {
    const matchesSearch = s.name.toLowerCase().includes(search.toLowerCase()) || (s.code || '').toLowerCase().includes(search.toLowerCase());
    const matchesYear = filterYear === 'all' || s.school_year === filterYear;
    return matchesSearch && matchesYear;
  });

  // Group by year
  const byYear = SCHOOL_YEARS.map((y) => ({
    ...y,
    items: filtered.filter((s) => s.school_year === y.value),
  }));

  return (
    <div>
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-6">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Materias</h2>
          <p className="text-sm text-gray-500 mt-0.5">{subjects.length} materias registradas</p>
        </div>
        <Button onClick={openCreate}><Plus className="h-4 w-4" /> Nueva Materia</Button>
      </div>

      <div className="flex flex-col sm:flex-row gap-3 mb-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input placeholder="Buscar por nombre o código..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-10 w-full" />
        </div>
        <Select value={filterYear} onChange={(e) => setFilterYear(e.target.value === 'all' ? 'all' : Number(e.target.value))} className="sm:w-40">
          <option value="all">Todos los años</option>
          {SCHOOL_YEARS.map((y) => <option key={y.value} value={y.value}>{y.label}</option>)}
        </Select>
      </div>

      {loading ? (
        <div className="bg-white rounded-xl border border-gray-200 p-8 text-center text-gray-400">Cargando...</div>
      ) : filtered.length === 0 ? (
        <div className="bg-white rounded-xl border border-gray-200">
          <EmptyState
            icon={<BookOpen className="h-8 w-8" />}
            title="No hay materias"
            description="Registra las materias del pensum educativo."
            action={<Button onClick={openCreate}><Plus className="h-4 w-4" /> Nueva Materia</Button>}
          />
        </div>
      ) : (
        <div className="space-y-4">
          {byYear.map((group) => group.items.length > 0 && (
            <div key={group.value} className="bg-white rounded-xl border border-gray-200 overflow-hidden">
              <div className="px-4 py-3 bg-gray-50 border-b border-gray-200 flex items-center gap-2">
                <BookOpen className="h-4 w-4 text-blue-600" />
                <h3 className="font-semibold text-gray-700 text-sm">{group.label}</h3>
                <Badge color="blue">{group.items.length}</Badge>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-gray-100 text-left">
                      <th className="px-4 py-2.5 font-semibold text-gray-600 whitespace-nowrap">Código</th>
                      <th className="px-4 py-2.5 font-semibold text-gray-600 whitespace-nowrap">Nombre</th>
                      <th className="px-4 py-2.5 font-semibold text-gray-600 whitespace-nowrap">Año</th>
                      <th className="px-4 py-2.5 font-semibold text-gray-600 whitespace-nowrap">Profesor</th>
                      <th className="px-4 py-2.5 font-semibold text-gray-600 text-right">Acciones</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-50">
                    {group.items.map((s) => (
                      <tr key={s.id} className="hover:bg-gray-50 transition-colors">
                        <td className="px-4 py-2.5 font-mono text-xs text-gray-500 whitespace-nowrap">{s.code || '—'}</td>
                        <td className="px-4 py-2.5 text-gray-900 whitespace-nowrap">{s.name}</td>
                        <td className="px-4 py-2.5 whitespace-nowrap">{yearLabel(s.school_year)}</td>
                        <td className="px-4 py-2.5 whitespace-nowrap text-gray-600">{s.teacher_id ? (teachers.find((t) => t.id === s.teacher_id) ? fullName(teachers.find((t) => t.id === s.teacher_id)!.first_name, teachers.find((t) => t.id === s.teacher_id)!.last_name) : '—') : '—'}</td>
                        <td className="px-4 py-2.5 whitespace-nowrap">
                          <div className="flex items-center justify-end gap-2">
                            <button onClick={() => openEdit(s)} className="p-1.5 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors">
                              <Pencil className="h-4 w-4" />
                            </button>
                            <button onClick={() => setConfirmDelete(s)} className="p-1.5 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors">
                              <Trash2 className="h-4 w-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          ))}
        </div>
      )}

      <Modal open={modalOpen} title={editing ? 'Editar Materia' : 'Nueva Materia'} onClose={() => { setModalOpen(false); resetForm(); }} size="sm">
        <div className="space-y-4">
          <FormField label="Nombre de la Materia" required error={errors.name}>
            <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Ej: Matemáticas" invalid={!!errors.name} />
          </FormField>
          <FormField label="Código">
            <Input value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value })} placeholder="Ej: MAT101" />
          </FormField>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <FormField label="Año Escolar" required>
              <Select value={form.school_year} onChange={(e) => setForm({ ...form, school_year: Number(e.target.value) })}>
                {SCHOOL_YEARS.map((y) => <option key={y.value} value={y.value}>{y.label}</option>)}
              </Select>
            </FormField>
            <FormField label="Profesor Asignado">
              <Select value={form.teacher_id} onChange={(e) => setForm({ ...form, teacher_id: e.target.value })}>
                <option value="">Sin asignar</option>
                {teachers.map((t) => <option key={t.id} value={t.id}>{fullName(t.first_name, t.last_name)}</option>)}
              </Select>
            </FormField>
          </div>
          <div className="flex justify-end gap-3 pt-2 border-t border-gray-100">
            <Button variant="outline" onClick={() => { setModalOpen(false); resetForm(); }}>Cancelar</Button>
            <Button onClick={handleSubmit}>{editing ? 'Guardar Cambios' : 'Crear Materia'}</Button>
          </div>
        </div>
      </Modal>

      <ConfirmModal
        open={!!confirmDelete}
        title="Eliminar Materia"
        message={`¿Estás seguro de eliminar "${confirmDelete?.name}"? Se eliminarán también las inscripciones y notas relacionadas.`}
        confirmText="Eliminar"
        onConfirm={handleDelete}
        onCancel={() => setConfirmDelete(null)}
      />
    </div>
  );
}
