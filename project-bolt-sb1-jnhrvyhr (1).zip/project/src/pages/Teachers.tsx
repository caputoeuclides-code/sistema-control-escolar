import { useCallback, useEffect, useState } from 'react';
import { supabase, TABLES } from '@/lib/supabase';
import type { Teacher, Subject } from '@/lib/types';
import { useToast } from '@/components/Toast';
import { ConfirmModal, Modal } from '@/components/Modal';
import { Button, EmptyState, FormField, Input } from '@/components/ui';
import { onlyDigits, fullName } from '@/lib/utils';
import { UserCog, Plus, Pencil, Trash2, Search, Mail, Phone, MapPin, AlertCircle, FileDown, FileSpreadsheet } from 'lucide-react';
import { exportTeachersPDF, exportTeachersExcel } from '@/lib/exportReports';

const CEDULA_MAX = 11;
const PHONE_MAX = 11;

interface TeachersProps {
  subjects: Subject[];
}

export function Teachers({ subjects }: TeachersProps) {
  const { showToast } = useToast();
  const [teachers, setTeachers] = useState<Teacher[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Teacher | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<Teacher | null>(null);
  const [form, setForm] = useState({
    cedula: '', first_name: '', last_name: '', phone: '', email: '', address: '',
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const load = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase.from(TABLES.TEACHERS).select('*').order('created_at', { ascending: false });
    if (error) {
      showToast('Error al cargar profesores', 'error');
    } else {
      setTeachers(data as Teacher[]);
    }
    setLoading(false);
  }, [showToast]);

  useEffect(() => { load(); }, [load]);

  const resetForm = () => {
    setForm({ cedula: '', first_name: '', last_name: '', phone: '', email: '', address: '' });
    setErrors({});
    setEditing(null);
  };

  const openCreate = () => { resetForm(); setModalOpen(true); };

  const openEdit = (t: Teacher) => {
    setEditing(t);
    setForm({
      cedula: t.cedula,
      first_name: t.first_name,
      last_name: t.last_name,
      phone: t.phone || '',
      email: t.email || '',
      address: t.address || '',
    });
    setErrors({});
    setModalOpen(true);
  };

  // Field-level validation that runs on every keystroke
  const validateField = (field: string, value: string): string => {
    switch (field) {
      case 'cedula':
        if (!value.trim()) return 'La cédula es obligatoria';
        if (!/^\d+$/.test(value)) return 'Solo se permiten dígitos (0-9)';
        if (value.length > CEDULA_MAX) return `Máximo ${CEDULA_MAX} dígitos`;
        return '';
      case 'phone':
        if (!value.trim()) return 'El teléfono es obligatorio';
        if (!/^\d+$/.test(value)) return 'Solo se permiten dígitos (0-9)';
        if (value.length > PHONE_MAX) return `Máximo ${PHONE_MAX} dígitos`;
        return '';
      case 'first_name':
        if (!value.trim()) return 'El nombre es obligatorio';
        return '';
      case 'last_name':
        if (!value.trim()) return 'El apellido es obligatorio';
        return '';
      case 'email':
        if (!value.trim()) return 'El email es obligatorio';
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) return 'Email no válido';
        return '';
      case 'address':
        if (!value.trim()) return 'La dirección es obligatoria';
        return '';
      default:
        return '';
    }
  };

  const handleChange = (field: string, value: string) => {
    let val = value;
    if (field === 'cedula' || field === 'phone') {
      val = onlyDigits(value);
    }
    setForm((prev) => ({ ...prev, [field]: val }));
    const err = validateField(field, val);
    setErrors((prev) => ({ ...prev, [field]: err }));
  };

  const validateAll = (): boolean => {
    const e: Record<string, string> = {};
    (Object.keys(form) as (keyof typeof form)[]).forEach((field) => {
      const err = validateField(field, form[field]);
      if (err) e[field] = err;
    });
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = async () => {
    if (!validateAll()) return;
    const payload = {
      cedula: form.cedula.trim(),
      first_name: form.first_name.trim(),
      last_name: form.last_name.trim(),
      phone: form.phone.trim(),
      email: form.email.trim(),
      address: form.address.trim(),
    };
    if (editing) {
      const { error } = await supabase.from(TABLES.TEACHERS).update(payload).eq('id', editing.id);
      if (error) {
        showToast(error.message.includes('duplicate') ? 'Ya existe un profesor con esa cédula' : 'Error al actualizar', 'error');
        return;
      }
      showToast('Profesor actualizado correctamente', 'success');
    } else {
      const { error } = await supabase.from(TABLES.TEACHERS).insert(payload);
      if (error) {
        showToast(error.message.includes('duplicate') ? 'Ya existe un profesor con esa cédula' : 'Error al crear profesor', 'error');
        return;
      }
      showToast('Profesor creado correctamente', 'success');
    }
    setModalOpen(false);
    resetForm();
    load();
  };

  const handleDelete = async () => {
    if (!confirmDelete) return;
    const { error } = await supabase.from(TABLES.TEACHERS).delete().eq('id', confirmDelete.id);
    if (error) {
      showToast('Error al eliminar profesor', 'error');
    } else {
      showToast('Profesor eliminado correctamente', 'success');
      load();
    }
    setConfirmDelete(null);
  };

  const filtered = teachers.filter((t) => {
    const q = search.toLowerCase();
    return fullName(t.first_name, t.last_name).toLowerCase().includes(q) || t.cedula.includes(search);
  });

  const handleExportPDF = () => {
    if (filtered.length === 0) {
      showToast('No hay profesores para exportar', 'warning');
      return;
    }
    exportTeachersPDF({ teachers: filtered, subjects });
    showToast('PDF descargado correctamente', 'success');
  };

  const handleExportExcel = () => {
    if (filtered.length === 0) {
      showToast('No hay profesores para exportar', 'warning');
      return;
    }
    exportTeachersExcel({ teachers: filtered, subjects });
    showToast('Excel descargado correctamente', 'success');
  };

  return (
    <div>
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-6">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Profesores</h2>
          <p className="text-sm text-gray-500 mt-0.5">{teachers.length} profesores registrados</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button variant="outline" onClick={handleExportPDF}>
            <FileDown className="h-4 w-4" />
            Descargar PDF
          </Button>
          <Button variant="outline" onClick={handleExportExcel}>
            <FileSpreadsheet className="h-4 w-4" />
            Descargar Excel
          </Button>
          <Button onClick={openCreate}><Plus className="h-4 w-4" /> Nuevo Profesor</Button>
        </div>
      </div>

      <div className="relative mb-4">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
        <Input
          placeholder="Buscar por nombre o cédula..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="pl-10 w-full"
        />
      </div>

      <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
        {loading ? (
          <div className="p-8 text-center text-gray-400">Cargando...</div>
        ) : filtered.length === 0 ? (
          <EmptyState
            icon={<UserCog className="h-8 w-8" />}
            title="No hay profesores"
            description="Registra el primer profesor del sistema."
            action={<Button onClick={openCreate}><Plus className="h-4 w-4" /> Nuevo Profesor</Button>}
          />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-200 bg-gray-50 text-left">
                  <th className="px-4 py-3 font-semibold text-gray-600 whitespace-nowrap">Cédula</th>
                  <th className="px-4 py-3 font-semibold text-gray-600 whitespace-nowrap">Nombre</th>
                  <th className="px-4 py-3 font-semibold text-gray-600 whitespace-nowrap">Teléfono</th>
                  <th className="px-4 py-3 font-semibold text-gray-600 whitespace-nowrap">Materias</th>
                  <th className="px-4 py-3 font-semibold text-gray-600 whitespace-nowrap">Email</th>
                  <th className="px-4 py-3 font-semibold text-gray-600 text-right">Acciones</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {filtered.map((t) => (
                  <tr key={t.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-4 py-3 font-mono text-xs text-gray-700 whitespace-nowrap">{t.cedula}</td>
                    <td className="px-4 py-3 text-gray-900 whitespace-nowrap">{fullName(t.first_name, t.last_name)}</td>
                    <td className="px-4 py-3 text-gray-600 whitespace-nowrap">{t.phone || '—'}</td>
                    <td className="px-4 py-3 text-gray-600 whitespace-nowrap">
                      {(() => {
                        const ts = subjects.filter((s) => s.teacher_id === t.id);
                        return ts.length > 0 ? ts.map((s) => s.name).join(', ') : 'Sin asignar';
                      })()}
                    </td>
                    <td className="px-4 py-3 text-gray-600 whitespace-nowrap">{t.email || '—'}</td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      <div className="flex items-center justify-end gap-2">
                        <button onClick={() => openEdit(t)} className="p-1.5 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors">
                          <Pencil className="h-4 w-4" />
                        </button>
                        <button onClick={() => setConfirmDelete(t)} className="p-1.5 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors">
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Create/Edit Modal */}
      <Modal
        open={modalOpen}
        title={editing ? 'Editar Profesor' : 'Nuevo Profesor'}
        onClose={() => { setModalOpen(false); resetForm(); }}
        size="md"
      >
        <div className="space-y-4">
          {/* Cédula + Teléfono */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <FormField label="Cédula de Identidad" required error={errors.cedula}>
              <div className="relative">
                <Input
                  value={form.cedula}
                  onChange={(e) => handleChange('cedula', e.target.value)}
                  placeholder="Ej: 1098250000"
                  invalid={!!errors.cedula}
                  maxLength={CEDULA_MAX}
                  inputMode="numeric"
                  className="pl-9"
                />
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs font-mono text-gray-400 pointer-events-none">
                  {form.cedula.length}/{CEDULA_MAX}
                </span>
              </div>
            </FormField>
            <FormField label="Teléfono" required error={errors.phone}>
              <div className="relative">
                <Input
                  value={form.phone}
                  onChange={(e) => handleChange('phone', e.target.value)}
                  placeholder="Ej: 04121234567"
                  invalid={!!errors.phone}
                  maxLength={PHONE_MAX}
                  inputMode="numeric"
                  className="pl-9"
                />
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs font-mono text-gray-400 pointer-events-none">
                  {form.phone.length}/{PHONE_MAX}
                </span>
              </div>
            </FormField>
          </div>

          {/* Nombres + Apellidos */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <FormField label="Nombres" required error={errors.first_name}>
              <Input
                value={form.first_name}
                onChange={(e) => handleChange('first_name', e.target.value)}
                placeholder="Nombres del profesor"
                invalid={!!errors.first_name}
              />
            </FormField>
            <FormField label="Apellidos" required error={errors.last_name}>
              <Input
                value={form.last_name}
                onChange={(e) => handleChange('last_name', e.target.value)}
                placeholder="Apellidos del profesor"
                invalid={!!errors.last_name}
              />
            </FormField>
          </div>

          {/* Email */}
          <FormField label="Email" required error={errors.email}>
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                type="email"
                value={form.email}
                onChange={(e) => handleChange('email', e.target.value)}
                placeholder="profesor@escuela.edu.ve"
                invalid={!!errors.email}
                className="pl-9"
              />
            </div>
          </FormField>

          {/* Dirección */}
          <FormField label="Dirección de Habitación" required error={errors.address}>
            <div className="relative">
              <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400 mt-0.5" />
              <Input
                value={form.address}
                onChange={(e) => handleChange('address', e.target.value)}
                placeholder="Calle, casa, urbanización, ciudad"
                invalid={!!errors.address}
                className="pl-9"
              />
            </div>
          </FormField>

          {/* Validation summary */}
          {Object.values(errors).some((v) => v) && (
            <div className="flex items-start gap-2 rounded-lg bg-red-50 border border-red-200 p-3">
              <AlertCircle className="h-4 w-4 text-red-500 flex-shrink-0 mt-0.5" />
              <p className="text-sm text-red-600">Revisa los campos marcados en rojo antes de continuar.</p>
            </div>
          )}

          <div className="flex justify-end gap-3 pt-2 border-t border-gray-100">
            <Button variant="outline" onClick={() => { setModalOpen(false); resetForm(); }}>Cancelar</Button>
            <Button onClick={handleSubmit} disabled={Object.values(errors).some((v) => v)}>
              {editing ? 'Guardar Cambios' : 'Crear Profesor'}
            </Button>
          </div>
        </div>
      </Modal>

      {/* Delete confirmation modal */}
      <ConfirmModal
        open={!!confirmDelete}
        title="Eliminar Profesor"
        message={`¿Estás seguro de eliminar a ${confirmDelete ? fullName(confirmDelete.first_name, confirmDelete.last_name) : ''}? Esta acción no se puede deshacer.`}
        confirmText="Sí, Eliminar"
        cancelText="Cancelar"
        variant="danger"
        onConfirm={handleDelete}
        onCancel={() => setConfirmDelete(null)}
      />
    </div>
  );
}
