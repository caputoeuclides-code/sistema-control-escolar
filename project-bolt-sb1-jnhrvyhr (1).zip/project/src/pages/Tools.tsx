import { useState } from 'react';
import { DevModule } from '@/pages/DevModule';
import { Manual } from '@/pages/Manual';
import { Wrench, HelpCircle } from 'lucide-react';

type ToolsTab = 'dev' | 'manual';

export function Tools() {
  const [tab, setTab] = useState<ToolsTab>('dev');

  return (
    <div>
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
          <Wrench className="h-6 w-6 text-blue-600" />
          Herramientas
        </h2>
        <p className="text-sm text-gray-500 mt-0.5">Respaldos y restauración de información</p>
      </div>

      {/* Internal tabs */}
      <div className="flex gap-2 mb-6 rounded-lg bg-gray-100 p-1 w-fit">
        <button
          onClick={() => setTab('dev')}
          className={`flex items-center gap-2 rounded-md px-4 py-2 text-sm font-medium transition-all ${
            tab === 'dev' ? 'bg-white text-blue-700 shadow-sm' : 'text-gray-500 hover:text-gray-700'
          }`}
        >
          <Wrench className="h-4 w-4" />
          Gestión de Datos
        </button>
        <button
          onClick={() => setTab('manual')}
          className={`flex items-center gap-2 rounded-md px-4 py-2 text-sm font-medium transition-all ${
            tab === 'manual' ? 'bg-white text-blue-700 shadow-sm' : 'text-gray-500 hover:text-gray-700'
          }`}
        >
          <HelpCircle className="h-4 w-4" />
          Manual de Usuario
        </button>
      </div>

      {tab === 'dev' ? <DevModule /> : <Manual />}
    </div>
  );
}
