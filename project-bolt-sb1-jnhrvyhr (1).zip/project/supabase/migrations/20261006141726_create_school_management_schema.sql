/*
# School Management System Schema (Single-tenant, no auth)

1. New Tables
- `representatives`: Guardian/parent info (cedula, name, phone, email, relationship, address)
- `teachers`: Teacher info (cedula, name, phone, email, specialty)
- `students`: Student info (cedula, name, birth date, gender, school year 1-5, section, representative link, phone, address, repeating flag, pending subjects, status)
- `subjects`: Subjects by school year (name, code, year 1-5)
- `enrollments`: Student-subject enrollment records
- `grades`: Grades per student per subject per lapso (1-3), Venezuelan 0-20 scale

2. Security
- RLS enabled on all tables.
- Single-tenant no-auth app: all policies use `TO anon, authenticated` with `USING (true)` / `WITH CHECK (true)` because data is intentionally shared/public.

3. Notes
- Cédula fields are unique identifiers (Venezuelan national ID).
- Grades use 0-20 scale with 3 lapsos (terms) per school year.
- Students track repeating status and pending subjects from prior years.
- All foreign keys use ON DELETE CASCADE for data consistency.
*/

CREATE TABLE IF NOT EXISTS representatives (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  cedula text UNIQUE NOT NULL,
  first_name text NOT NULL,
  last_name text NOT NULL,
  phone text,
  email text,
  relationship text,
  address text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE representatives ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "rep_select" ON representatives;
CREATE POLICY "rep_select" ON representatives FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "rep_insert" ON representatives;
CREATE POLICY "rep_insert" ON representatives FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "rep_update" ON representatives;
CREATE POLICY "rep_update" ON representatives FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "rep_delete" ON representatives;
CREATE POLICY "rep_delete" ON representatives FOR DELETE TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS teachers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  cedula text UNIQUE NOT NULL,
  first_name text NOT NULL,
  last_name text NOT NULL,
  phone text,
  email text,
  specialty text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE teachers ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "teacher_select" ON teachers;
CREATE POLICY "teacher_select" ON teachers FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "teacher_insert" ON teachers;
CREATE POLICY "teacher_insert" ON teachers FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "teacher_update" ON teachers;
CREATE POLICY "teacher_update" ON teachers FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "teacher_delete" ON teachers;
CREATE POLICY "teacher_delete" ON teachers FOR DELETE TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS students (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  cedula text UNIQUE NOT NULL,
  first_name text NOT NULL,
  last_name text NOT NULL,
  birth_date date,
  gender text DEFAULT 'M',
  school_year int DEFAULT 1 CHECK (school_year >= 1 AND school_year <= 5),
  section text DEFAULT 'A',
  representative_id uuid REFERENCES representatives(id) ON DELETE SET NULL,
  phone text,
  address text,
  is_repeating boolean DEFAULT false,
  pending_subjects jsonb DEFAULT '[]'::jsonb,
  status text DEFAULT 'activo',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE students ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "student_select" ON students;
CREATE POLICY "student_select" ON students FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "student_insert" ON students;
CREATE POLICY "student_insert" ON students FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "student_update" ON students;
CREATE POLICY "student_update" ON students FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "student_delete" ON students;
CREATE POLICY "student_delete" ON students FOR DELETE TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS subjects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  code text,
  school_year int DEFAULT 1 CHECK (school_year >= 1 AND school_year <= 5),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE subjects ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "subject_select" ON subjects;
CREATE POLICY "subject_select" ON subjects FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "subject_insert" ON subjects;
CREATE POLICY "subject_insert" ON subjects FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "subject_update" ON subjects;
CREATE POLICY "subject_update" ON subjects FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "subject_delete" ON subjects;
CREATE POLICY "subject_delete" ON subjects FOR DELETE TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS enrollments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id uuid NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  subject_id uuid NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
  school_year int DEFAULT 1,
  enrolled_date date DEFAULT CURRENT_DATE,
  status text DEFAULT 'activo',
  created_at timestamptz DEFAULT now(),
  UNIQUE(student_id, subject_id)
);

ALTER TABLE enrollments ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "enr_select" ON enrollments;
CREATE POLICY "enr_select" ON enrollments FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "enr_insert" ON enrollments;
CREATE POLICY "enr_insert" ON enrollments FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "enr_update" ON enrollments;
CREATE POLICY "enr_update" ON enrollments FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "enr_delete" ON enrollments;
CREATE POLICY "enr_delete" ON enrollments FOR DELETE TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS grades (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id uuid NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  subject_id uuid NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
  lapso int NOT NULL CHECK (lapso >= 1 AND lapso <= 3),
  grade numeric DEFAULT 0 CHECK (grade >= 0 AND grade <= 20),
  created_at timestamptz DEFAULT now(),
  UNIQUE(student_id, subject_id, lapso)
);

ALTER TABLE grades ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "grade_select" ON grades;
CREATE POLICY "grade_select" ON grades FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "grade_insert" ON grades;
CREATE POLICY "grade_insert" ON grades FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "grade_update" ON grades;
CREATE POLICY "grade_update" ON grades FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "grade_delete" ON grades;
CREATE POLICY "grade_delete" ON grades FOR DELETE TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_students_representative ON students(representative_id);
CREATE INDEX IF NOT EXISTS idx_students_year ON students(school_year);
CREATE INDEX IF NOT EXISTS idx_enrollments_student ON enrollments(student_id);
CREATE INDEX IF NOT EXISTS idx_enrollments_subject ON enrollments(subject_id);
CREATE INDEX IF NOT EXISTS idx_grades_student ON grades(student_id);
CREATE INDEX IF NOT EXISTS idx_grades_subject ON grades(subject_id);
CREATE INDEX IF NOT EXISTS idx_subjects_year ON subjects(school_year);
