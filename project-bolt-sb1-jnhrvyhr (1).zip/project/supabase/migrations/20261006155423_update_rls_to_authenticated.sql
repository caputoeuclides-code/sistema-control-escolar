/*
# Update RLS policies to authenticated-only

1. Changes
- All 6 tables (representatives, teachers, students, subjects, enrollments, grades) had policies scoped to `anon, authenticated` with `USING (true)`.
- Now that the app has a sign-in screen, policies are re-scoped to `authenticated` only.
- Data is shared among all authenticated users (school staff), so `USING (true)` remains appropriate — the auth gate is at the app level.

2. Security
- Drops all existing anon+authenticated policies and recreates them as authenticated-only.
- This prevents unauthenticated (anon) access to any school data.
*/

-- representatives
DROP POLICY IF EXISTS "rep_select" ON representatives;
CREATE POLICY "rep_select" ON representatives FOR SELECT TO authenticated USING (true);
DROP POLICY IF EXISTS "rep_insert" ON representatives;
CREATE POLICY "rep_insert" ON representatives FOR INSERT TO authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "rep_update" ON representatives;
CREATE POLICY "rep_update" ON representatives FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "rep_delete" ON representatives;
CREATE POLICY "rep_delete" ON representatives FOR DELETE TO authenticated USING (true);

-- teachers
DROP POLICY IF EXISTS "teacher_select" ON teachers;
CREATE POLICY "teacher_select" ON teachers FOR SELECT TO authenticated USING (true);
DROP POLICY IF EXISTS "teacher_insert" ON teachers;
CREATE POLICY "teacher_insert" ON teachers FOR INSERT TO authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "teacher_update" ON teachers;
CREATE POLICY "teacher_update" ON teachers FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "teacher_delete" ON teachers;
CREATE POLICY "teacher_delete" ON teachers FOR DELETE TO authenticated USING (true);

-- students
DROP POLICY IF EXISTS "student_select" ON students;
CREATE POLICY "student_select" ON students FOR SELECT TO authenticated USING (true);
DROP POLICY IF EXISTS "student_insert" ON students;
CREATE POLICY "student_insert" ON students FOR INSERT TO authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "student_update" ON students;
CREATE POLICY "student_update" ON students FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "student_delete" ON students;
CREATE POLICY "student_delete" ON students FOR DELETE TO authenticated USING (true);

-- subjects
DROP POLICY IF EXISTS "subject_select" ON subjects;
CREATE POLICY "subject_select" ON subjects FOR SELECT TO authenticated USING (true);
DROP POLICY IF EXISTS "subject_insert" ON subjects;
CREATE POLICY "subject_insert" ON subjects FOR INSERT TO authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "subject_update" ON subjects;
CREATE POLICY "subject_update" ON subjects FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "subject_delete" ON subjects;
CREATE POLICY "subject_delete" ON subjects FOR DELETE TO authenticated USING (true);

-- enrollments
DROP POLICY IF EXISTS "enr_select" ON enrollments;
CREATE POLICY "enr_select" ON enrollments FOR SELECT TO authenticated USING (true);
DROP POLICY IF EXISTS "enr_insert" ON enrollments;
CREATE POLICY "enr_insert" ON enrollments FOR INSERT TO authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "enr_update" ON enrollments;
CREATE POLICY "enr_update" ON enrollments FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "enr_delete" ON enrollments;
CREATE POLICY "enr_delete" ON enrollments FOR DELETE TO authenticated USING (true);

-- grades
DROP POLICY IF EXISTS "grade_select" ON grades;
CREATE POLICY "grade_select" ON grades FOR SELECT TO authenticated USING (true);
DROP POLICY IF EXISTS "grade_insert" ON grades;
CREATE POLICY "grade_insert" ON grades FOR INSERT TO authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "grade_update" ON grades;
CREATE POLICY "grade_update" ON grades FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "grade_delete" ON grades;
CREATE POLICY "grade_delete" ON grades FOR DELETE TO authenticated USING (true);
