/*
# Add address column to teachers table

1. Changes
- Adds `address` column (text, nullable) to the `teachers` table.
- This replaces the removed `specialty` field for the teacher form.
- The `specialty` column is NOT dropped (data safety: never drop columns).

2. Security
- No policy changes. Existing authenticated-only RLS policies remain in effect.
*/

ALTER TABLE teachers ADD COLUMN IF NOT EXISTS address text;
