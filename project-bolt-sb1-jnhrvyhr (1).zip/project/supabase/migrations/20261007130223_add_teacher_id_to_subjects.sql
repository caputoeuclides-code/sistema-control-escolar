/*
# Add teacher_id to subjects table

1. Changes
- Adds `teacher_id` column (nullable uuid) to the `subjects` table, referencing `teachers(id)`.
- This links each subject to the teacher responsible for it, enabling the teacher workload report (Nómina y Carga Académica).
- Adds an index on `subjects(teacher_id)` for efficient lookups.
2. Security
- No RLS policy changes needed — subjects already have full CRUD policies for anon + authenticated.
- The new column is nullable so existing subject rows remain valid.
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'subjects' AND column_name = 'teacher_id'
  ) THEN
    ALTER TABLE subjects ADD COLUMN teacher_id uuid REFERENCES teachers(id) ON DELETE SET NULL;
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_subjects_teacher ON subjects(teacher_id);
